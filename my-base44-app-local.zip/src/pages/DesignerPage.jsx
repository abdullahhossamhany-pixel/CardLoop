const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";

import { PageHeader, LoadingState, EmptyState } from "@/components/ui-parts";
import { Button } from "@/components/ui/button";
import CardDesigner from "@/components/CardDesigner";
import CardPreview from "@/components/CardPreview";
import { Plus, Palette } from "lucide-react";

export default function DesignerPage() {
  const { user } = useAuth();
  const isBusiness = user?.data?.account_type === "business";
  const [designs, setDesigns] = useState(null);
  const [editing, setEditing] = useState(null);
  const [showNew, setShowNew] = useState(false);

  const load = async () => {
    try {
      setDesigns(
        isBusiness
          ? await db.entities.GiftCardDesign.filter({ business_id: user.data.business_id })
          : await db.entities.GiftCardDesign.filter({ owner_id: user.id })
      );
    } catch (e) { setDesigns([]); }
  };

  useEffect(() => { load(); }, [user, isBusiness]);

  if (designs === null) return <LoadingState />;

  if (showNew || editing) {
    return (
      <div>
        <PageHeader
          title={editing ? "Edit design" : "Card Designer"}
          subtitle="Drag-and-drop gift card designer"
          actions={<Button variant="outline" size="sm" onClick={() => { setEditing(null); setShowNew(false); }}>Back to library</Button>}
        />
        <CardDesigner
          initialDesign={editing || undefined}
          businessMode={isBusiness}
          ownerId={isBusiness ? undefined : user.id}
          businessId={isBusiness ? user.data.business_id : undefined}
          onSave={() => { setEditing(null); setShowNew(false); load(); }}
        />
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        title="Card Designer"
        subtitle="Create and manage gift card designs"
        actions={<Button onClick={() => setShowNew(true)}><Plus className="w-4 h-4 mr-1" /> New design</Button>}
      />
      {designs.length === 0 ? (
        <EmptyState icon={Palette} title="No designs yet" desc="Create a custom gift card design with the drag-and-drop editor." action={<Button onClick={() => setShowNew(true)}><Plus className="w-4 h-4 mr-1" /> New design</Button>} />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {designs.map((d) => (
            <div key={d.id} className="rounded-2xl border bg-card p-3">
              <CardPreview design={d} showInfo={false} />
              <div className="mt-3 flex items-center justify-between">
                <div>
                  <p className="font-medium text-sm truncate">{d.name}</p>
                  <p className="text-xs text-muted-foreground capitalize">{d.type}</p>
                </div>
                <Button size="sm" variant="outline" onClick={() => setEditing(d)}>Edit</Button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}