const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";

import { PageHeader, LoadingState, EmptyState } from "@/components/ui-parts";
import { formatMoney } from "@/lib/giftcard";
import { Receipt } from "lucide-react";

export default function AdminTransactions() {
  const [txns, setTxns] = useState(null);
  useEffect(() => { (async () => { try { setTxns(await db.entities.Transaction.list()); } catch { setTxns([]); } })(); }, []);
  if (!txns) return <LoadingState />;
  return (
    <div>
      <PageHeader title="All Transactions" subtitle="Platform-wide ledger" />
      {txns.length === 0 ? <EmptyState icon={Receipt} title="No transactions" /> : (
        <div className="rounded-2xl border bg-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-muted-foreground"><tr><th className="text-left font-medium px-4 py-3">ID</th><th className="text-left font-medium px-4 py-3">Type</th><th className="text-left font-medium px-4 py-3">Amount</th><th className="text-left font-medium px-4 py-3">Date</th></tr></thead>
            <tbody>
              {txns.map((t) => (
                <tr key={t.id} className="border-t">
                  <td className="px-4 py-3 font-mono text-xs">{t.transaction_id}</td>
                  <td className="px-4 py-3 capitalize">{t.type}</td>
                  <td className="px-4 py-3 font-semibold">{formatMoney(t.amount, t.currency)}</td>
                  <td className="px-4 py-3 text-muted-foreground">{new Date(t.created_date).toLocaleString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}