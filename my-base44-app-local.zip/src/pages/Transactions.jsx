const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { useAuth } from "@/lib/AuthContext";

import { PageHeader, LoadingState, EmptyState, Badge } from "@/components/ui-parts";
import { formatMoney } from "@/lib/giftcard";
import { Receipt, ArrowUpRight, ArrowDownLeft } from "lucide-react";

export default function Transactions() {
  const { user } = useAuth();
  const isBusiness = user?.data?.account_type === "business";
  const [txns, setTxns] = useState(null);
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    (async () => {
      try {
        if (isBusiness) {
          setTxns(await db.entities.Transaction.filter({ business_id: user.data.business_id }, "-created_date"));
        } else {
          // personal: get all my cards then their txns
          const cards = await db.entities.GiftCard.filter({ owner_id: user.id, owner_type: "user" });
          const all = [];
          for (const c of cards) {
            const t = await db.entities.Transaction.filter({ gift_card_id: c.id }, "-created_date");
            all.push(...t);
          }
          all.sort((a, b) => new Date(b.created_date) - new Date(a.created_date));
          setTxns(all);
        }
      } catch (e) { console.error(e); setTxns([]); }
    })();
  }, [user, isBusiness]);

  if (txns === null) return <LoadingState />;

  const visible = filter === "all" ? txns : txns.filter((t) => t.type === filter);

  return (
    <div>
      <PageHeader title="Transactions" subtitle="Full transaction ledger" />
      <div className="flex gap-2 overflow-x-auto mb-5">
        {["all", "issue", "load", "redeem", "refund", "adjustment", "transfer", "reversal"].map((f) => (
          <button key={f} onClick={() => setFilter(f)} className={`px-3 py-1.5 rounded-lg text-sm font-medium whitespace-nowrap capitalize ${filter === f ? "bg-violet-600 text-white" : "border bg-card"}`}>{f}</button>
        ))}
      </div>
      {visible.length === 0 ? (
        <EmptyState icon={Receipt} title="No transactions" desc="Transactions will appear here." />
      ) : (
        <div className="rounded-2xl border bg-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-muted-foreground">
                <tr>
                  <th className="text-left font-medium px-4 py-3">Type</th>
                  <th className="text-left font-medium px-4 py-3">Amount</th>
                  <th className="text-left font-medium px-4 py-3">Prev bal</th>
                  <th className="text-left font-medium px-4 py-3">New bal</th>
                  <th className="text-left font-medium px-4 py-3">Date</th>
                  <th className="text-left font-medium px-4 py-3">Status</th>
                </tr>
              </thead>
              <tbody>
                {visible.map((t) => (
                  <tr key={t.id} className="border-t hover:bg-muted/30">
                    <td className="px-4 py-3 capitalize font-medium">{t.type}</td>
                    <td className="px-4 py-3 font-semibold">{t.type === "redeem" ? "-" : "+"}{formatMoney(t.amount, t.currency)}</td>
                    <td className="px-4 py-3 text-muted-foreground">{formatMoney(t.previous_balance, t.currency)}</td>
                    <td className="px-4 py-3">{formatMoney(t.new_balance, t.currency)}</td>
                    <td className="px-4 py-3 text-muted-foreground">{new Date(t.created_date).toLocaleString()}</td>
                    <td className="px-4 py-3"><Badge status={t.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}