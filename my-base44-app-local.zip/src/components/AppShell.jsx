import React, { useState, useEffect } from "react";
import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";

import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Gift, LayoutDashboard, CreditCard, Layers, Users, Receipt, Store,
  Palette, ShoppingCart, Code, Webhook, BarChart3, ShieldCheck, Settings,
  Menu, X, LogOut, Sun, Moon, ChevronRight, Sparkles, Building2, User,
} from "lucide-react";

const personalNav = [
  { label: "Dashboard", path: "/app", icon: LayoutDashboard },
  { label: "My Gift Cards", path: "/app/cards", icon: CreditCard },
  { label: "Create Card", path: "/app/create", icon: Sparkles },
  { label: "Card Designer", path: "/app/designer", icon: Palette },
  { label: "Transactions", path: "/app/transactions", icon: Receipt },
  { label: "Settings", path: "/app/settings", icon: Settings },
];

const businessNav = [
  { label: "Overview", path: "/app", icon: LayoutDashboard },
  { label: "Gift Cards", path: "/app/cards", icon: CreditCard },
  { label: "Programs", path: "/app/programs", icon: Layers },
  { label: "Customers", path: "/app/customers", icon: Users },
  { label: "Transactions", path: "/app/transactions", icon: Receipt },
  { label: "Card Designer", path: "/app/designer", icon: Palette },
  { label: "Design Library", path: "/app/designs", icon: Palette },
  { label: "Physical Cards", path: "/app/physical", icon: ShoppingCart },
  { label: "Stores", path: "/app/stores", icon: Store },
  { label: "POS Systems", path: "/app/pos", icon: CreditCard },
  { label: "Online Stores", path: "/app/online-stores", icon: Store },
  { label: "API & Developers", path: "/app/api", icon: Code },
  { label: "Webhooks", path: "/app/webhooks", icon: Webhook },
  { label: "Analytics", path: "/app/analytics", icon: BarChart3 },
  { label: "Team", path: "/app/team", icon: Users },
  { label: "Verification", path: "/app/verification", icon: ShieldCheck },
  { label: "Billing", path: "/app/billing", icon: Receipt },
  { label: "Settings", path: "/app/settings", icon: Settings },
];

const adminNav = [
  { label: "Admin Overview", path: "/admin", icon: LayoutDashboard },
  { label: "Users", path: "/admin/users", icon: Users },
  { label: "Businesses", path: "/admin/businesses", icon: Building2 },
  { label: "Gift Cards", path: "/admin/giftcards", icon: CreditCard },
  { label: "Transactions", path: "/admin/transactions", icon: Receipt },
  { label: "Settings", path: "/admin/settings", icon: Settings },
];

export default function AppShell({ variant = "app" }) {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [dark, setDark] = useState(() => {
    const saved = localStorage.getItem("gc-theme");
    if (saved) return saved === "dark";
    return document.documentElement.classList.contains("dark");
  });

  useEffect(() => {
    if (dark) {
      document.documentElement.classList.add("dark");
      localStorage.setItem("gc-theme", "dark");
    } else {
      document.documentElement.classList.remove("dark");
      localStorage.setItem("gc-theme", "light");
    }
  }, [dark]);

  const nav = variant === "admin" ? adminNav : user?.data?.account_type === "business" ? businessNav : personalNav;
  const isBusiness = user?.data?.account_type === "business";

  useEffect(() => {
    setSidebarOpen(false);
  }, [location.pathname]);

  const handleLogout = async () => {
    await logout(false);
    navigate("/login");
  };

  const brandLabel = variant === "admin" ? "Admin Console" : isBusiness ? "Business Console" : "GiftLoop";

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile top bar */}
      <div className="lg:hidden sticky top-0 z-40 flex items-center justify-between px-4 h-14 border-b bg-background/80 backdrop-blur">
        <button onClick={() => setSidebarOpen(true)} className="p-2 -ml-2 rounded-lg hover:bg-muted">
          <Menu className="w-5 h-5" />
        </button>
        <div className="flex items-center gap-2 font-semibold">
          <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-violet-600 to-fuchsia-500 flex items-center justify-center">
            <Gift className="w-4 h-4 text-white" />
          </div>
          {brandLabel}
        </div>
        <button onClick={() => setDark(!dark)} className="p-2 rounded-lg hover:bg-muted">
          {dark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
        </button>
      </div>

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 w-64 bg-sidebar border-r flex flex-col transition-transform lg:translate-x-0",
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="h-16 flex items-center gap-2 px-5 border-b">
          <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-violet-600 to-fuchsia-500 flex items-center justify-center">
            <Gift className="w-5 h-5 text-white" />
          </div>
          <span className="font-bold text-lg tracking-tight">{brandLabel}</span>
          <button onClick={() => setSidebarOpen(false)} className="ml-auto lg:hidden p-1 rounded-lg hover:bg-muted">
            <X className="w-5 h-5" />
          </button>
        </div>

        <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-0.5">
          {nav.map((item) => {
            const active = location.pathname === item.path || (item.path !== "/app" && location.pathname.startsWith(item.path));
            return (
              <Link
                key={item.path}
                to={item.path}
                className={cn(
                  "flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors",
                  active
                    ? "bg-sidebar-accent text-sidebar-accent-foreground"
                    : "text-sidebar-foreground/70 hover:bg-sidebar-accent/50 hover:text-sidebar-foreground"
                )}
              >
                <item.icon className="w-4 h-4 shrink-0" />
                {item.label}
                {active && <ChevronRight className="w-4 h-4 ml-auto" />}
              </Link>
            );
          })}
        </nav>

        <div className="border-t p-3 space-y-2">
          {variant !== "admin" && (
            <Link to="/admin" className="flex items-center gap-2 text-xs px-3 py-2 rounded-lg text-muted-foreground hover:bg-muted">
              <ShieldCheck className="w-4 h-4" /> Admin Console
            </Link>
          )}
          <button
            onClick={() => setDark(!dark)}
            className="hidden lg:flex w-full items-center gap-2 text-sm px-3 py-2 rounded-lg text-muted-foreground hover:bg-muted"
          >
            {dark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            {dark ? "Light mode" : "Dark mode"}
          </button>
          <div className="flex items-center gap-2 px-2">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center text-white text-sm font-semibold">
              {(user?.full_name || user?.email || "U").charAt(0).toUpperCase()}
            </div>
            <div className="min-w-0 flex-1">
              <p className="text-sm font-medium truncate">{user?.full_name || user?.email}</p>
              <p className="text-xs text-muted-foreground truncate capitalize">{user?.data?.account_type || "personal"}</p>
            </div>
            <button onClick={handleLogout} className="p-1.5 rounded-lg hover:bg-muted text-muted-foreground" title="Log out">
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </aside>

      {sidebarOpen && (
        <div className="fixed inset-0 z-40 bg-black/40 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Main */}
      <div className="lg:pl-64">
        <main className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
}