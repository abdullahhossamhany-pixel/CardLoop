const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { useAuth } from "@/lib/AuthContext";

import { PageHeader, LoadingState, EmptyState } from "@/components/ui-parts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Users, UserPlus, Mail, Loader2 } from "lucide-react";
import { toast } from "@/components/ui/use-toast";

export default function Team() {
  const { user } = useAuth();
  const [members, setMembers] = useState(null);
  const [email, setEmail] = useState("");
  const [role, setRole] = useState("user");
  const [inviting, setInviting] = useState(false);

  const load = async () => {
    try { setMembers(await db.entities.User.list()); } catch (e) { setMembers([]); }
  };
  useEffect(() => { load(); }, []);

  const invite = async () => {
    if (!email) { toast({ title: "Email required", variant: "destructive" }); return; }
    setInviting(true);
    try {
      await db.users.inviteUser(email, role);
      setEmail(""); toast({ title: "Invitation sent", description: `${email} invited as ${role}` });
      await load();
    } catch (e) { toast({ title: "Failed", description: e.message, variant: "destructive" }); }
    finally { setInviting(false); }
  };

  if (members === null) return <LoadingState />;

  return (
    <div>
      <PageHeader title="Team" subtitle="Invite and manage team members" />
      <div className="rounded-2xl border bg-card p-5 mb-6">
        <h3 className="font-semibold mb-3 flex items-center gap-2"><UserPlus className="w-4 h-4" /> Invite member</h3>
        <div className="flex flex-col sm:flex-row gap-3">
          <Input type="email" placeholder="teammate@example.com" value={email} onChange={(e) => setEmail(e.target.value)} />
          <select value={role} onChange={(e) => setRole(e.target.value)} className="h-10 rounded-md border bg-background px-3 text-sm">
            <option value="user">User</option>
            <option value="admin">Admin</option>
          </select>
          <Button onClick={invite} disabled={inviting}>{inviting && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}Invite</Button>
        </div>
      </div>
      {members.length === 0 ? (
        <EmptyState icon={Users} title="No team members" desc="Invite teammates to collaborate." />
      ) : (
        <div className="rounded-2xl border bg-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-muted-foreground"><tr><th className="text-left font-medium px-4 py-3">Name</th><th className="text-left font-medium px-4 py-3">Email</th><th className="text-left font-medium px-4 py-3">Role</th></tr></thead>
            <tbody>
              {members.map((m) => (
                <tr key={m.id} className="border-t">
                  <td className="px-4 py-3 font-medium">{m.full_name || "—"}</td>
                  <td className="px-4 py-3 text-muted-foreground">{m.email}</td>
                  <td className="px-4 py-3 capitalize">{m.role}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}