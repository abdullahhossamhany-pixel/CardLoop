const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { useAuth } from "@/lib/AuthContext";

import { PageHeader, LoadingState, Badge, NotConfiguredBanner } from "@/components/ui-parts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ShieldCheck, Loader2, Upload, FileText } from "lucide-react";
import { useBusiness } from "@/lib/useBusiness";
import { toast } from "@/components/ui/use-toast";

export default function Verification() {
  const { user } = useAuth();
  const { business, reload } = useBusiness();
  const [form, setForm] = useState({ legal_name: "", display_name: "", email: "", phone: "", country: "", address: "", website_url: "", category: "", registration_info: "" });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (business) setForm({
      legal_name: business.legal_name || "", display_name: business.display_name || "", email: business.email || user.email,
      phone: business.phone || "", country: business.country || "", address: business.address || "",
      website_url: business.website_url || "", category: business.category || "", registration_info: business.registration_info || "",
    });
  }, [business, user]);

  const submit = async () => {
    setSaving(true);
    try {
      await db.entities.Business.update(business.id, { ...form, verification_status: "pending" });
      await reload();
      toast({ title: "Verification submitted", description: "Your information is pending review." });
    } catch (e) { toast({ title: "Failed", description: e.message, variant: "destructive" }); }
    finally { setSaving(false); }
  };

  if (!business) return <LoadingState />;

  return (
    <div>
      <PageHeader title="Business Verification" subtitle="Verify your business to unlock physical NFC cards and production features" />
      <div className="flex items-center gap-3 mb-6">
        <span className="text-sm text-muted-foreground">Status:</span>
        <Badge status={business.verification_status} />
      </div>

      <NotConfiguredBanner title="Identity verification provider not connected" desc="This form collects business information and prepares it for a legitimate KYC/KYB provider. Do not upload sensitive identity documents here yet — once a verification provider is connected, documents will be stored privately and never publicly accessible." />

      <div className="grid lg:grid-cols-[2fr_1fr] gap-6 mt-6">
        <div className="rounded-2xl border bg-card p-6 space-y-4">
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="space-y-2"><Label>Legal/Business name</Label><Input value={form.legal_name} onChange={(e) => setForm({ ...form, legal_name: e.target.value })} /></div>
            <div className="space-y-2"><Label>Store/Display name</Label><Input value={form.display_name} onChange={(e) => setForm({ ...form, display_name: e.target.value })} /></div>
            <div className="space-y-2"><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
            <div className="space-y-2"><Label>Phone</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            <div className="space-y-2"><Label>Country</Label><Input value={form.country} onChange={(e) => setForm({ ...form, country: e.target.value })} /></div>
            <div className="space-y-2"><Label>Category</Label><Input value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} /></div>
            <div className="space-y-2 sm:col-span-2"><Label>Address</Label><Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
            <div className="space-y-2"><Label>Website URL</Label><Input value={form.website_url} onChange={(e) => setForm({ ...form, website_url: e.target.value })} /></div>
            <div className="space-y-2 sm:col-span-2"><Label>Business registration info</Label><Textarea value={form.registration_info} onChange={(e) => setForm({ ...form, registration_info: e.target.value })} rows={3} placeholder="Registration number, jurisdiction, etc." /></div>
          </div>
          <Button onClick={submit} disabled={saving || business.verification_status === "pending"}>
            {saving ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Submitting…</> : <><ShieldCheck className="w-4 h-4 mr-2" /> Submit for verification</>}
          </Button>
        </div>
        <div className="rounded-2xl border bg-card p-5 space-y-3">
          <h3 className="font-semibold flex items-center gap-2"><FileText className="w-4 h-4" /> Verification statuses</h3>
          <ul className="text-sm text-muted-foreground space-y-1.5">
            <li><Badge status="not_submitted" /> Not submitted</li>
            <li><Badge status="pending" /> Pending review</li>
            <li><Badge status="verified" /> Verified</li>
            <li><Badge status="rejected" /> Rejected</li>
            <li><Badge status="needs_more_info" /> Needs more info</li>
          </ul>
          <p className="text-xs text-muted-foreground pt-2 border-t">Document upload will appear here once a KYC provider is connected. Documents will be stored privately.</p>
        </div>
      </div>
    </div>
  );
}