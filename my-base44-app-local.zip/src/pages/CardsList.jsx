const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";

import { PageHeader, Badge, LoadingState, EmptyState } from "@/components/ui-parts";
import { formatMoney, maskCardNumber } from "@/lib/giftcard";
import { Button } from "@/components/ui/button";
import { CreditCard, Plus, Search } from "lucide-react";
import { Input } from "@/components/ui/input";

export default function CardsList() {
  const { user } = useAuth();
  const isBusiness = user?.data?.account_type === "business";
  const [cards, setCards] = useState(null);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    (async () => {
      try {
        if (isBusiness) {
          setCards(await db.entities.GiftCard.filter({ business_id: user.data.business_id }, "-created_date"));
        } else {
          setCards(await db.entities.GiftCard.filter({ owner_id: user.id, owner_type: "user" }, "-created_date"));
        }
      } catch (e) { console.error(e); setCards([]); }
    })();
  }, [user, isBusiness]);

  if (cards === null) return <LoadingState />;

  const visible = cards.filter((c) => {
    if (filter !== "all" && c.status !== filter) return false;
    if (search && !c.card_number.includes(search)) return false;
    return true;
  });

  return (
    <div>
      <PageHeader
        title="Gift Cards"
        subtitle={isBusiness ? "All cards issued by your business" : "Your gift cards"}
        actions={<Link to="/app/create"><Button><Plus className="w-4 h-4 mr-1" /> New Card</Button></Link>}
      />

      <div className="flex flex-col sm:flex-row gap-3 mb-5">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Search card number…" className="pl-9" />
        </div>
        <div className="flex gap-2 overflow-x-auto">
          {["all", "active", "frozen", "redeemed", "expired", "revoked", "deleted"].map((f) => (
            <Button key={f} size="sm" variant={filter === f ? "default" : "outline"} onClick={() => setFilter(f)} className="capitalize whitespace-nowrap">{f}</Button>
          ))}
        </div>
      </div>

      {visible.length === 0 ? (
        <EmptyState icon={CreditCard} title="No cards found" desc={cards.length === 0 ? "Create your first gift card to get started." : "Try a different filter."} action={cards.length === 0 && <Link to="/app/create"><Button size="sm"><Plus className="w-4 h-4 mr-1" /> Create card</Button></Link>} />
      ) : (
        <div className="rounded-2xl border bg-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="bg-muted/50 text-muted-foreground">
                <tr>
                  <th className="text-left font-medium px-4 py-3">Card number</th>
                  <th className="text-left font-medium px-4 py-3">Balance</th>
                  <th className="text-left font-medium px-4 py-3">Initial</th>
                  <th className="text-left font-medium px-4 py-3">Created</th>
                  <th className="text-left font-medium px-4 py-3">Status</th>
                </tr>
              </thead>
              <tbody>
                {visible.map((c) => (
                  <tr key={c.id} className="border-t hover:bg-muted/30">
                    <td className="px-4 py-3"><Link to={`/app/cards/${c.id}`} className="font-mono font-medium hover:text-violet-600">{maskCardNumber(c.card_number)}</Link></td>
                    <td className="px-4 py-3 font-semibold">{formatMoney(c.balance, c.currency)}</td>
                    <td className="px-4 py-3 text-muted-foreground">{formatMoney(c.initial_value, c.currency)}</td>
                    <td className="px-4 py-3 text-muted-foreground">{new Date(c.created_date).toLocaleDateString()}</td>
                    <td className="px-4 py-3"><Badge status={c.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}