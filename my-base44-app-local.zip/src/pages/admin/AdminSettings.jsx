const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { useAuth } from "@/lib/AuthContext";

import { PageHeader, LoadingState, NotConfiguredBanner, Badge } from "@/components/ui-parts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Loader2, Save, KeyRound, Eye, EyeOff, Check, ShieldCheck, CreditCard } from "lucide-react";
import { toast } from "@/components/ui/use-toast";

export default function AdminSettings() {
  const { user } = useAuth();
  const [settings, setSettings] = useState(null);
  const [nowpaymentsKey, setNowpaymentsKey] = useState("");
  const [nowpaymentsServerKey, setNowpaymentsServerKey] = useState("");
  const [showKey, setShowKey] = useState(false);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    try {
      const all = await db.entities.AppSetting.list();
      setSettings(all);
      const np = all.find((s) => s.key === "nowpayments_api_key");
      const npSrv = all.find((s) => s.key === "nowpayments_server_key");
      setNowpaymentsKey(np?.value || "");
      setNowpaymentsServerKey(npSrv?.value || "");
    } catch (e) { setSettings([]); }
  };
  useEffect(() => { load(); }, []);

  const saveSetting = async (key, value, isSecret = true) => {
    setSaving(true);
    try {
      const existing = settings.find((s) => s.key === key);
      if (existing) {
        await db.entities.AppSetting.update(existing.id, { value, is_secret: isSecret, updated_by_id: user.id });
      } else {
        await db.entities.AppSetting.create({ key, value, is_secret: isSecret, updated_by_id: user.id });
      }
      await load();
      toast({ title: `${key} saved`, description: "The setting is stored securely and only visible to admins." });
    } catch (e) { toast({ title: "Failed", description: e.message, variant: "destructive" }); }
    finally { setSaving(false); }
  };

  const saveAudit = async (action) => {
    try {
      await db.entities.AuditLog.create({ actor_id: user.id, actor_type: "admin", action, entity_type: "AppSetting", details: { ts: new Date().toISOString() } });
    } catch {}
  };

  const saveNowpayments = async () => {
    await saveSetting("nowpayments_api_key", nowpaymentsKey, true);
    await saveSetting("nowpayments_server_key", nowpaymentsServerKey, true);
    await saveAudit("nowpayments_api_key_updated");
  };

  if (settings === null) return <LoadingState />;
  const configured = !!(nowpaymentsKey || nowpaymentsServerKey);

  return (
    <div>
      <PageHeader title="Platform Settings" subtitle="Configure integrations and platform-wide settings" />

      <div className="rounded-2xl bg-gradient-to-r from-slate-800 to-slate-900 p-5 text-white mb-6 flex items-center gap-3">
        <ShieldCheck className="w-6 h-6" />
        <div>
          <p className="font-semibold">Admin only</p>
          <p className="text-sm opacity-80">Secrets entered here are stored in the database with admin-only access. Changes are audit-logged.</p>
        </div>
      </div>

      {/* NOW Payments */}
      <div className="rounded-2xl border bg-card p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 rounded-lg bg-violet-100 dark:bg-violet-900/40 flex items-center justify-center"><CreditCard className="w-5 h-5 text-violet-600" /></div>
            <div>
              <h3 className="font-semibold">NOW Payments</h3>
              <p className="text-xs text-muted-foreground">Crypto payment provider for business subscriptions</p>
            </div>
          </div>
          {configured ? <Badge status="active" /> : <Badge status="not_configured" />}
        </div>

        {!configured && (
          <div className="mb-4">
            <NotConfiguredBanner title="NOW Payments not configured" desc="Enter your NOW Payments API keys below to enable crypto payments for business subscriptions. Get your keys from your NOW Payments dashboard. The keys are stored securely and never exposed in frontend code." />
          </div>
        )}

        <div className="space-y-4">
          <div className="space-y-2">
            <Label>API Key</Label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <KeyRound className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  type={showKey ? "text" : "password"}
                  value={nowpaymentsKey}
                  onChange={(e) => setNowpaymentsKey(e.target.value)}
                  placeholder="Enter your NOW Payments API key"
                  className="pl-9 pr-10 font-mono"
                />
                <button onClick={() => setShowKey(!showKey)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
                  {showKey ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>
          </div>
          <div className="space-y-2">
            <Label>Server Key (IPN / webhook signing)</Label>
            <Input
              type={showKey ? "text" : "password"}
              value={nowpaymentsServerKey}
              onChange={(e) => setNowpaymentsServerKey(e.target.value)}
              placeholder="Enter your NOW Payments server key"
              className="font-mono"
            />
          </div>
          <Button onClick={saveNowpayments} disabled={saving}>
            {saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Save className="w-4 h-4 mr-2" />}
            Save NOW Payments keys
          </Button>
          {configured && (
            <p className="text-xs text-emerald-600 flex items-center gap-1"><Check className="w-3 h-3" /> NOW Payments is configured. Business subscription payments can now be processed through this provider.</p>
          )}
        </div>
      </div>

      {/* Other integrations (placeholders) */}
      <div className="grid sm:grid-cols-2 gap-4">
        <div className="rounded-2xl border bg-card p-5">
          <h3 className="font-semibold mb-1">KYC / Verification Provider</h3>
          <p className="text-sm text-muted-foreground mb-3">For business identity verification.</p>
          <Badge status="not_configured" />
        </div>
        <div className="rounded-2xl border bg-card p-5">
          <h3 className="font-semibold mb-1">NFC Card Manufacturer</h3>
          <p className="text-sm text-muted-foreground mb-3">For physical card production.</p>
          <Badge status="not_configured" />
        </div>
        <div className="rounded-2xl border bg-card p-5">
          <h3 className="font-semibold mb-1">POS Provider</h3>
          <p className="text-sm text-muted-foreground mb-3">Direct POS integrations.</p>
          <Badge status="not_configured" />
        </div>
        <div className="rounded-2xl border bg-card p-5">
          <h3 className="font-semibold mb-1">Third-party Gift Card Marketplace</h3>
          <p className="text-sm text-muted-foreground mb-3">Authorized supplier APIs.</p>
          <Badge status="not_configured" />
        </div>
      </div>
    </div>
  );
}