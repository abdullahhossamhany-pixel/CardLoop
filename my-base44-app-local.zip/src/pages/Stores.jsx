const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { useAuth } from "@/lib/AuthContext";

import { PageHeader, LoadingState, EmptyState } from "@/components/ui-parts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Store as StoreIcon, Plus, Pencil, Trash2, MapPin } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "@/components/ui/use-toast";

export default function Stores() {
  const { user } = useAuth();
  const [items, setItems] = useState(null);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name: "", address: "", location: "", phone: "" });

  const load = async () => { try { setItems(await db.entities.Store.filter({ business_id: user.data.business_id })); } catch { setItems([]); } };
  useEffect(() => { load(); }, [user]);

  const save = async () => {
    if (!form.name) { toast({ title: "Name required", variant: "destructive" }); return; }
    try {
      if (editing) await db.entities.Store.update(editing.id, form);
      else await db.entities.Store.create({ ...form, business_id: user.data.business_id, is_active: true });
      setOpen(false); await load(); toast({ title: "Store saved" });
    } catch (e) { toast({ title: "Failed", description: e.message, variant: "destructive" }); }
  };
  const remove = async (s) => { try { await db.entities.Store.delete(s.id); await load(); } catch {} };

  if (items === null) return <LoadingState />;

  return (
    <div>
      <PageHeader title="Stores" subtitle="Your physical store locations" actions={<Button onClick={() => { setEditing(null); setForm({ name: "", address: "", location: "", phone: "" }); setOpen(true); }}><Plus className="w-4 h-4 mr-1" /> Add store</Button>} />
      {items.length === 0 ? (
        <EmptyState icon={StoreIcon} title="No stores yet" desc="Add your physical store locations to connect POS terminals." action={<Button onClick={() => { setEditing(null); setForm({ name: "", address: "", location: "", phone: "" }); setOpen(true); }}><Plus className="w-4 h-4 mr-1" /> Add store</Button>} />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {items.map((s) => (
            <div key={s.id} className="rounded-2xl border bg-card p-5">
              <div className="flex items-start justify-between">
                <div className="w-10 h-10 rounded-lg bg-blue-100 dark:bg-blue-900/40 flex items-center justify-center"><StoreIcon className="w-5 h-5 text-blue-600" /></div>
                <div className="flex gap-1">
                  <Button size="icon" variant="ghost" onClick={() => { setEditing(s); setForm({ name: s.name, address: s.address, location: s.location, phone: s.phone }); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                  <Button size="icon" variant="ghost" onClick={() => remove(s)}><Trash2 className="w-4 h-4 text-rose-600" /></Button>
                </div>
              </div>
              <h3 className="font-semibold mt-3">{s.name}</h3>
              {s.address && <p className="text-sm text-muted-foreground mt-1 flex items-start gap-1"><MapPin className="w-3.5 h-3.5 mt-0.5 shrink-0" />{s.address}</p>}
              {s.phone && <p className="text-sm text-muted-foreground mt-1">{s.phone}</p>}
            </div>
          ))}
        </div>
      )}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? "Edit store" : "Add store"}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="space-y-2"><Label>Name *</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
            <div className="space-y-2"><Label>Address</Label><Input value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} /></div>
            <div className="space-y-2"><Label>Location / City</Label><Input value={form.location} onChange={(e) => setForm({ ...form, location: e.target.value })} /></div>
            <div className="space-y-2"><Label>Phone</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={save}>Save</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}