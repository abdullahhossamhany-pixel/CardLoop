const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Gift, User, Building2, ArrowRight, Loader2, Check, Sparkles } from "lucide-react";
import { computeTrialEnd } from "@/lib/giftcard";
import { toast } from "@/components/ui/use-toast";

export default function Onboarding() {
  const { user, checkUserAuth } = useAuth();
  const navigate = useNavigate();
  const [step, setStep] = useState("choose"); // choose | business
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    legal_name: "",
    display_name: "",
    country: "",
    address: "",
    website_url: "",
    category: "",
    phone: "",
  });

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const choosePersonal = async () => {
    setLoading(true);
    try {
      await db.auth.updateMe({ account_type: "personal" });
      await checkUserAuth();
      navigate("/app");
    } catch (e) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const submitBusiness = async (e) => {
    e.preventDefault();
    if (!form.legal_name || !form.display_name) {
      toast({ title: "Please fill required fields", variant: "destructive" });
      return;
    }
    setLoading(true);
    try {
      const now = new Date();
      const trialEnd = computeTrialEnd(now);
      const biz = await db.entities.Business.create({
        ...form,
        email: user.email,
        trial_start_date: now.toISOString(),
        trial_end_date: trialEnd.toISOString(),
        subscription_status: "trial",
        verification_status: "not_submitted",
        is_test_data: false,
      });
      await db.auth.updateMe({ account_type: "business", business_id: biz.id });
      await db.entities.Subscription.create({
        business_id: biz.id,
        plan: "trial",
        status: "trial",
        start_date: now.toISOString(),
        end_date: trialEnd.toISOString(),
        payment_provider: "nowpayments",
        provider_status: "not_configured",
      });
      await checkUserAuth();
      navigate("/app");
    } catch (e) {
      toast({ title: "Error", description: e.message, variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-b from-violet-50 to-background dark:from-violet-950/30 px-4 py-10">
      <div className="w-full max-w-3xl">
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-violet-600 to-fuchsia-500 mb-4">
            <Gift className="w-7 h-7 text-white" />
          </div>
          <h1 className="text-3xl font-bold tracking-tight">Welcome to GiftLoop</h1>
          <p className="text-muted-foreground mt-2">Choose your account type to get started.</p>
        </div>

        {step === "choose" && (
          <div className="grid md:grid-cols-2 gap-5">
            <button
              onClick={choosePersonal}
              disabled={loading}
              className="text-left rounded-2xl border bg-card p-7 hover:border-violet-500 hover:shadow-lg transition-all"
            >
              <div className="w-12 h-12 rounded-xl bg-emerald-100 dark:bg-emerald-900/40 flex items-center justify-center mb-4">
                <User className="w-6 h-6 text-emerald-600 dark:text-emerald-300" />
              </div>
              <h2 className="text-xl font-bold">Personal Account</h2>
              <p className="text-sm text-muted-foreground mt-1 mb-4">For individuals who want to create and manage their own gift cards.</p>
              <div className="space-y-1.5 text-sm">
                <p className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-500" /> Free forever</p>
                <p className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-500" /> Up to 5 active cards</p>
                <p className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-500" /> Card Designer & uploads</p>
              </div>
              <div className="mt-5 flex items-center text-violet-600 font-medium text-sm">
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <>Continue <ArrowRight className="w-4 h-4 ml-1" /></>}
              </div>
            </button>

            <button
              onClick={() => setStep("business")}
              disabled={loading}
              className="text-left rounded-2xl border-2 border-violet-500 bg-card p-7 hover:shadow-lg transition-all relative"
            >
              <div className="absolute -top-3 right-5 px-2.5 py-1 rounded-full bg-violet-600 text-white text-xs font-semibold flex items-center gap-1">
                <Sparkles className="w-3 h-3" /> 6 Months Free
              </div>
              <div className="w-12 h-12 rounded-xl bg-violet-100 dark:bg-violet-900/40 flex items-center justify-center mb-4">
                <Building2 className="w-6 h-6 text-violet-600 dark:text-violet-300" />
              </div>
              <h2 className="text-xl font-bold">Business Account</h2>
              <p className="text-sm text-muted-foreground mt-1 mb-4">Full business trial — no credit card required.</p>
              <div className="space-y-1.5 text-sm">
                <p className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-500" /> Unlimited gift cards</p>
                <p className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-500" /> POS & online store integrations</p>
                <p className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-500" /> API, webhooks & analytics</p>
              </div>
              <div className="mt-5 flex items-center text-violet-600 font-medium text-sm">
                Set up business <ArrowRight className="w-4 h-4 ml-1" />
              </div>
            </button>
          </div>
        )}

        {step === "business" && (
          <form onSubmit={submitBusiness} className="rounded-2xl border bg-card p-7 space-y-4">
            <div className="flex items-center gap-2 text-violet-600 font-medium mb-2">
              <Building2 className="w-5 h-5" /> Business setup — 6-month full trial
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Legal/Business name *</Label>
                <Input value={form.legal_name} onChange={(e) => set("legal_name", e.target.value)} required placeholder="Acme Inc." />
              </div>
              <div className="space-y-2">
                <Label>Store/Display name *</Label>
                <Input value={form.display_name} onChange={(e) => set("display_name", e.target.value)} required placeholder="Acme Gifts" />
              </div>
              <div className="space-y-2">
                <Label>Country</Label>
                <Input value={form.country} onChange={(e) => set("country", e.target.value)} placeholder="United States" />
              </div>
              <div className="space-y-2">
                <Label>Phone</Label>
                <Input value={form.phone} onChange={(e) => set("phone", e.target.value)} placeholder="+1 555 0100" />
              </div>
              <div className="space-y-2 sm:col-span-2">
                <Label>Address</Label>
                <Input value={form.address} onChange={(e) => set("address", e.target.value)} placeholder="123 Main St" />
              </div>
              <div className="space-y-2">
                <Label>Website URL</Label>
                <Input value={form.website_url} onChange={(e) => set("website_url", e.target.value)} placeholder="https://example.com" />
              </div>
              <div className="space-y-2">
                <Label>Business category</Label>
                <Input value={form.category} onChange={(e) => set("category", e.target.value)} placeholder="Retail" />
              </div>
            </div>
            <p className="text-xs text-muted-foreground">
              You can complete full verification later. Your 6-month trial starts now and includes every business feature.
            </p>
            <div className="flex gap-3 pt-2">
              <Button type="button" variant="outline" onClick={() => setStep("choose")} disabled={loading}>Back</Button>
              <Button type="submit" disabled={loading} className="flex-1">
                {loading ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Creating business…</> : "Start 6-month trial"}
              </Button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}