import React from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";
import { Button } from "@/components/ui/button";
import {
  Gift, Sparkles, Upload, Palette, CreditCard, Store, Code, ShieldCheck,
  Check, ArrowRight, Zap, Globe, Lock, LayoutDashboard,
} from "lucide-react";

const features = [
  { icon: Palette, title: "Drag-and-drop Card Designer", desc: "A Canva-style editor built for gift cards. Text, images, shapes, gradients, layers, undo/redo." },
  { icon: Upload, title: "Upload Your Own Design", desc: "Bring finished artwork, crop and position it on a realistic card preview." },
  { icon: CreditCard, title: "Physical NFC Cards", desc: "Order custom NFC gift cards for your stores — business only, with secure server-side balances." },
  { icon: Globe, title: "Online Store Integration", desc: "Connect your website and redeem cards through a clean developer API." },
  { icon: Store, title: "Physical POS Integration", desc: "Register POS terminals and redeem cards in-store with card number and PIN." },
  { icon: Code, title: "Business API & Webhooks", desc: "Generate API keys, configure signed webhooks, and build on test or production mode." },
];

const plans = [
  {
    name: "Personal",
    price: "Free",
    period: "forever",
    tag: "For individuals",
    features: ["Up to 5 active gift cards", "Card Designer & uploads", "Balances & transaction history", "Freeze / unfreeze cards", "Send & receive gift cards"],
    cta: "Create a personal account",
    highlight: false,
  },
  {
    name: "Business",
    price: "6 Months",
    period: "free trial",
    tag: "Full Business Trial",
    features: ["Unlimited gift cards", "Multiple gift-card programs", "POS & online store integrations", "API keys & webhooks", "Physical NFC card ordering", "Team management & analytics"],
    cta: "Start your 6-month trial",
    highlight: true,
  },
];

export default function Landing() {
  const { isAuthenticated, user } = useAuth();
  const hasAccount = !!user?.data?.account_type;
  return (
    <div className="min-h-screen bg-background">
      {/* Nav */}
      <header className="sticky top-0 z-40 border-b bg-background/80 backdrop-blur">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2 font-bold text-lg">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-br from-violet-600 to-fuchsia-500 flex items-center justify-center">
              <Gift className="w-5 h-5 text-white" />
            </div>
            GiftLoop
          </Link>
          <div className="flex items-center gap-2">
            {isAuthenticated ? (
              <>
                {user?.role === "admin" && <Link to="/admin"><Button variant="ghost" size="sm"><ShieldCheck className="w-4 h-4 mr-1" /> Admin</Button></Link>}
                <Link to={hasAccount ? "/app" : "/onboarding"}><Button size="sm"><LayoutDashboard className="w-4 h-4 mr-1" /> {hasAccount ? "Dashboard" : "Set up account"}</Button></Link>
              </>
            ) : (
              <>
                <Link to="/login"><Button variant="ghost" size="sm">Log in</Button></Link>
                <Link to="/register?returnTo=/onboarding"><Button size="sm">Get started</Button></Link>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 -z-10 bg-gradient-to-b from-violet-50 via-background to-background dark:from-violet-950/30" />
        <div className="absolute -z-10 top-20 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-gradient-to-br from-violet-400/20 to-fuchsia-400/20 rounded-full blur-3xl" />
        <div className="max-w-6xl mx-auto px-4 sm:px-6 pt-20 pb-16 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-violet-100 dark:bg-violet-900/40 text-violet-700 dark:text-violet-300 text-sm font-medium mb-6">
            <ShieldCheck className="w-4 h-4" /> Closed-loop gift cards — not bank cards
          </div>
          <h1 className="text-4xl sm:text-6xl font-bold tracking-tight max-w-3xl mx-auto leading-tight">
            Design, issue, and redeem <span className="bg-gradient-to-r from-violet-600 to-fuchsia-500 bg-clip-text text-transparent">custom gift cards</span>
          </h1>
          <p className="mt-6 text-lg text-muted-foreground max-w-2xl mx-auto">
            A complete gift-card platform for personal users and businesses. Create beautiful cards with our designer,
            connect your stores and website, and redeem in-store or online. These are closed-loop gift cards —
            not Visa, Mastercard, or mada.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
            {isAuthenticated ? (
              <Link to={hasAccount ? "/app" : "/onboarding"}><Button size="lg" className="h-12 px-8 text-base">{hasAccount ? "Go to dashboard" : "Complete setup"} <ArrowRight className="w-4 h-4 ml-2" /></Button></Link>
            ) : (
              <>
                <Link to="/register?returnTo=/onboarding"><Button size="lg" className="h-12 px-8 text-base">Start free <ArrowRight className="w-4 h-4 ml-2" /></Button></Link>
                <Link to="/login"><Button size="lg" variant="outline" className="h-12 px-8 text-base">Log in</Button></Link>
              </>
            )}
          </div>
          <div className="mt-6 flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm text-muted-foreground">
            <span className="flex items-center gap-1"><Check className="w-4 h-4 text-emerald-500" /> Personal free forever</span>
            <span className="flex items-center gap-1"><Check className="w-4 h-4 text-emerald-500" /> 6-month full business trial</span>
            <span className="flex items-center gap-1"><Check className="w-4 h-4 text-emerald-500" /> No credit card required</span>
          </div>
        </div>

        {/* Card preview mockup */}
        <div className="max-w-4xl mx-auto px-4 pb-20">
          <div className="grid sm:grid-cols-3 gap-4">
            {[
              { from: "from-violet-600", to: "to-fuchsia-500", label: "Birthday", value: "$100" },
              { from: "from-emerald-600", to: "to-teal-500", label: "Thank You", value: "$50" },
              { from: "from-amber-500", to: "to-orange-500", label: "Holiday", value: "$200" },
            ].map((c) => (
              <div key={c.label} className={`aspect-[1.586/1] rounded-2xl bg-gradient-to-br ${c.from} ${c.to} p-5 shadow-xl flex flex-col justify-between text-white`}>
                <div className="flex justify-between items-start">
                  <Gift className="w-7 h-7" />
                  <span className="text-xs opacity-80 font-mono">•••• ••••</span>
                </div>
                <div>
                  <p className="text-2xl font-bold">{c.value}</p>
                  <p className="text-sm opacity-90">{c.label} Gift Card</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight">Everything you need to run gift cards</h2>
          <p className="mt-3 text-muted-foreground">From design to redemption, in-store and online.</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((f) => (
            <div key={f.title} className="rounded-2xl border bg-card p-6 hover:shadow-md transition-shadow">
              <div className="w-11 h-11 rounded-xl bg-violet-100 dark:bg-violet-900/40 flex items-center justify-center mb-4">
                <f.icon className="w-5 h-5 text-violet-600 dark:text-violet-300" />
              </div>
              <h3 className="font-semibold mb-1.5">{f.title}</h3>
              <p className="text-sm text-muted-foreground">{f.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Plans */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight">Simple, honest pricing</h2>
          <p className="mt-3 text-muted-foreground">Personal is free forever. Business gets a full 6-month trial — no credit card.</p>
        </div>
        <div className="grid md:grid-cols-2 gap-6 items-start">
          {plans.map((p) => (
            <div
              key={p.name}
              className={`rounded-2xl border p-8 ${p.highlight ? "border-violet-500 shadow-lg ring-1 ring-violet-500/20" : "bg-card"}`}
            >
              {p.highlight && (
                <div className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-violet-600 text-white text-xs font-semibold mb-4">
                  <Zap className="w-3 h-3" /> {p.tag}
                </div>
              )}
              <h3 className="text-2xl font-bold">{p.name}</h3>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-4xl font-bold">{p.price}</span>
                <span className="text-muted-foreground">{p.period}</span>
              </div>
              <ul className="mt-6 space-y-3">
                {p.features.map((feat) => (
                  <li key={feat} className="flex items-start gap-2 text-sm">
                    <Check className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                    {feat}
                  </li>
                ))}
              </ul>
              <Link to={isAuthenticated ? (hasAccount ? "/app" : "/onboarding") : "/register?returnTo=/onboarding"} className="block mt-8">
                <Button className="w-full" variant={p.highlight ? "default" : "outline"}>{isAuthenticated ? (hasAccount ? "Go to dashboard" : "Complete setup") : p.cta}</Button>
              </Link>
            </div>
          ))}
        </div>
      </section>

      {/* Trust */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6 py-16">
        <div className="rounded-2xl bg-gradient-to-br from-violet-600 to-fuchsia-600 p-10 text-center text-white">
          <Lock className="w-10 h-10 mx-auto mb-4" />
          <h2 className="text-2xl font-bold">Secure by design</h2>
          <p className="mt-3 max-w-2xl mx-auto opacity-90">
            Role-based permissions, row-level security, hashed PINs, audit logs, idempotent transactions,
            and server-side balance authority. Card numbers are identifiers for our platform only —
            never bank card PANs.
          </p>
        </div>
      </section>

      <footer className="border-t">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-gradient-to-br from-violet-600 to-fuchsia-500 flex items-center justify-center">
              <Gift className="w-3.5 h-3.5 text-white" />
            </div>
            GiftLoop — Closed-loop gift card platform
          </div>
          <p>Not a bank. Not Visa, Mastercard, or mada.</p>
        </div>
      </footer>
    </div>
  );
}