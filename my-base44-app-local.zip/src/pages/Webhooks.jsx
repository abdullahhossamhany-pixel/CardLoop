const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { useAuth } from "@/lib/AuthContext";

import { PageHeader, LoadingState, EmptyState, Badge } from "@/components/ui-parts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Webhook as WebhookIcon, Plus, Trash2 } from "lucide-react";
import { generateUuid } from "@/lib/giftcard";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "@/components/ui/use-toast";

const EVENTS = [
  "giftcard.created", "giftcard.redeemed", "giftcard.frozen", "giftcard.unfrozen", "giftcard.revoked",
  "transaction.completed", "transaction.refunded", "physical_card.ordered", "physical_card.shipped", "physical_card.delivered",
];

export default function Webhooks() {
  const { user } = useAuth();
  const [items, setItems] = useState(null);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ url: "", events: [] });

  const load = async () => { try { setItems(await db.entities.Webhook.filter({ business_id: user.data.business_id })); } catch { setItems([]); } };
  useEffect(() => { load(); }, [user]);

  const toggleEvent = (ev) => setForm((f) => ({ ...f, events: f.events.includes(ev) ? f.events.filter((e) => e !== ev) : [...f.events, ev] }));

  const save = async () => {
    if (!form.url) { toast({ title: "URL required", variant: "destructive" }); return; }
    try {
      await db.entities.Webhook.create({ ...form, business_id: user.data.business_id, secret: generateUuid(), status: "active" });
      setOpen(false); setForm({ url: "", events: [] }); await load(); toast({ title: "Webhook added" });
    } catch (e) { toast({ title: "Failed", description: e.message, variant: "destructive" }); }
  };
  const remove = async (w) => { try { await db.entities.Webhook.delete(w.id); await load(); } catch {} };

  if (items === null) return <LoadingState />;

  return (
    <div>
      <PageHeader title="Webhooks" subtitle="Receive signed event notifications" actions={<Button onClick={() => setOpen(true)}><Plus className="w-4 h-4 mr-1" /> Add webhook</Button>} />
      <p className="text-sm text-muted-foreground mb-4">Webhook deliveries are signed with a secret and retried with exponential backoff. Delivery infrastructure is ready — connect a receiver endpoint to activate.</p>
      {items.length === 0 ? (
        <EmptyState icon={WebhookIcon} title="No webhooks" desc="Add an endpoint to receive event notifications." action={<Button onClick={() => setOpen(true)}><Plus className="w-4 h-4 mr-1" /> Add webhook</Button>} />
      ) : (
        <div className="space-y-3">
          {items.map((w) => (
            <div key={w.id} className="rounded-2xl border bg-card p-4">
              <div className="flex items-center justify-between">
                <p className="font-mono text-sm truncate">{w.url}</p>
                <div className="flex items-center gap-2"><Badge status={w.status} /><Button size="icon" variant="ghost" onClick={() => remove(w)}><Trash2 className="w-4 h-4 text-rose-600" /></Button></div>
              </div>
              <div className="flex flex-wrap gap-1.5 mt-2">
                {(w.events || []).map((e) => <span key={e} className="px-2 py-0.5 rounded-full bg-muted text-xs">{e}</span>)}
              </div>
            </div>
          ))}
        </div>
      )}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Add webhook</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="space-y-2"><Label>Endpoint URL *</Label><Input value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} placeholder="https://example.com/webhooks" /></div>
            <div className="space-y-2"><Label>Events</Label>
              <div className="grid grid-cols-2 gap-2 max-h-48 overflow-y-auto">
                {EVENTS.map((ev) => (
                  <label key={ev} className="flex items-center gap-2 text-sm">
                    <input type="checkbox" checked={form.events.includes(ev)} onChange={() => toggleEvent(ev)} /> {ev}
                  </label>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={save}>Add</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}