const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";

import { PageHeader, LoadingState, Badge } from "@/components/ui-parts";

export default function AdminBusinesses() {
  const [items, setItems] = useState(null);
  useEffect(() => { (async () => { try { setItems(await db.entities.Business.list()); } catch { setItems([]); } })(); }, []);
  if (!items) return <LoadingState />;
  return (
    <div>
      <PageHeader title="Businesses" subtitle="All registered businesses" />
      <div className="grid sm:grid-cols-2 gap-4">
        {items.map((b) => (
          <div key={b.id} className="rounded-2xl border bg-card p-5">
            <div className="flex items-start justify-between">
              <div><h3 className="font-semibold">{b.display_name}</h3><p className="text-xs text-muted-foreground">{b.legal_name}</p></div>
              <Badge status={b.verification_status} />
            </div>
            <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
              <div><p className="text-xs text-muted-foreground">Subscription</p><p className="capitalize">{b.subscription_status}</p></div>
              <div><p className="text-xs text-muted-foreground">Trial ends</p><p>{b.trial_end_date ? new Date(b.trial_end_date).toLocaleDateString() : "—"}</p></div>
              <div><p className="text-xs text-muted-foreground">Email</p><p className="truncate">{b.email}</p></div>
              <div><p className="text-xs text-muted-foreground">Country</p><p>{b.country || "—"}</p></div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}