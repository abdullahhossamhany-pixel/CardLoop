const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";

import { PageHeader, LoadingState } from "@/components/ui-parts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import CardDesigner from "@/components/CardDesigner";
import CardPreview from "@/components/CardPreview";
import { generateCardNumber, generatePin, generateUuid, generateTxnId, hashPin, formatMoney } from "@/lib/giftcard";
import { useBusiness, useTrialStatus } from "@/lib/useBusiness";
import { toast } from "@/components/ui/use-toast";
import {
  Upload, Palette, CreditCard, Check, Loader2, ArrowRight, ArrowLeft,
  Sparkles, Lock, Copy,
} from "lucide-react";

const MAX_PERSONAL_CARDS = 5;

export default function CreateCard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const isBusiness = user?.data?.account_type === "business";
  const { business } = useBusiness();
  const trial = useTrialStatus(business);

  const [step, setStep] = useState(1); // 1:method 2:design 3:details 4:done
  const [method, setMethod] = useState(null); // upload | designer | library
  const [uploadedUrl, setUploadedUrl] = useState("");
  const [design, setDesign] = useState(null);
  const [designs, setDesigns] = useState([]);
  const [programs, setPrograms] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [activeCount, setActiveCount] = useState(0);
  const [creating, setCreating] = useState(false);
  const [result, setResult] = useState(null);

  const [details, setDetails] = useState({
    value: 50,
    currency: "USD",
    expiration_date: "",
    program_id: "",
    customer_id: "",
    design_name: "My Card Design",
  });

  useEffect(() => {
    (async () => {
      try {
        const [ds, active] = await Promise.all([
          isBusiness
            ? db.entities.GiftCardDesign.filter({ business_id: user.data.business_id })
            : db.entities.GiftCardDesign.filter({ owner_id: user.id }),
          db.entities.GiftCard.filter({ owner_id: user.id, owner_type: "user", status: "active" }),
        ]);
        setDesigns(ds);
        setActiveCount(active.length);
        if (isBusiness) {
          setPrograms(await db.entities.GiftCardProgram.filter({ business_id: user.data.business_id }));
          setCustomers(await db.entities.Customer.filter({ business_id: user.data.business_id }));
        }
      } catch (e) { console.error(e); }
    })();
  }, [user, isBusiness]);

  // Personal 5-card limit check
  useEffect(() => {
    if (!isBusiness && step === 1 && activeCount >= MAX_PERSONAL_CARDS) {
      toast({ title: "Card limit reached", description: "Personal accounts can have up to 5 active gift cards. Delete one to create a new card.", variant: "destructive" });
    }
  }, [step, activeCount, isBusiness]);

  const handleUpload = async (file) => {
    if (!file) return;
    try {
      const { file_url } = await db.integrations.Core.UploadPublicFile({ file });
      setUploadedUrl(file_url);
    } catch (e) {
      toast({ title: "Upload failed", description: e.message, variant: "destructive" });
    }
  };

  const saveUploadDesign = async () => {
    try {
      const d = await db.entities.GiftCardDesign.create({
        name: details.design_name || "Uploaded Design",
        type: "uploaded",
        owner_id: isBusiness ? undefined : user.id,
        business_id: isBusiness ? user.data.business_id : undefined,
        front_image_url: uploadedUrl,
        front_background: { type: "image", image: uploadedUrl },
      });
      setDesign(d);
      setStep(3);
    } catch (e) {
      toast({ title: "Save failed", description: e.message, variant: "destructive" });
    }
  };

  const onDesignerSave = (saved) => {
    setDesign(saved);
    setStep(3);
  };

  const generate = async () => {
    if (!isBusiness && activeCount >= MAX_PERSONAL_CARDS) {
      toast({ title: "Card limit reached", description: "Delete a card first (5 active max).", variant: "destructive" });
      return;
    }
    setCreating(true);
    try {
      const cardNumber = generateCardNumber();
      const pin = generatePin();
      const pinHash = await hashPin(pin);
      const bid = isBusiness ? user.data.business_id : "";
      const program = programs.find((p) => p.id === details.program_id);

      const card = await db.entities.GiftCard.create({
        card_uuid: generateUuid(),
        card_number: cardNumber,
        pin_hash: pinHash,
        business_id: bid,
        program_id: details.program_id || undefined,
        owner_id: isBusiness ? (details.customer_id || undefined) : user.id,
        owner_type: isBusiness ? "customer" : "user",
        customer_id: details.customer_id || undefined,
        balance: Number(details.value),
        initial_value: Number(details.value),
        currency: program?.currency || details.currency,
        status: "active",
        expiration_date: details.expiration_date || undefined,
        design_id: design?.id,
        is_test_data: false,
      });

      await db.entities.Transaction.create({
        transaction_id: generateTxnId(),
        gift_card_id: card.id,
        business_id: bid || undefined,
        customer_id: details.customer_id || undefined,
        type: "issue",
        amount: Number(details.value),
        currency: card.currency,
        previous_balance: 0,
        new_balance: Number(details.value),
        status: "completed",
        reference: "initial_issue",
        is_test_data: false,
      });

      setResult({ card, pin });
      setStep(4);
    } catch (e) {
      toast({ title: "Failed to create card", description: e.message, variant: "destructive" });
    } finally {
      setCreating(false);
    }
  };

  if (programs === null) return <LoadingState />;

  // Step 4: success
  if (step === 4 && result) {
    return (
      <div className="max-w-lg mx-auto">
        <div className="rounded-2xl border bg-card p-8 text-center">
          <div className="w-14 h-14 rounded-full bg-emerald-100 dark:bg-emerald-900/40 flex items-center justify-center mx-auto mb-4">
            <Check className="w-7 h-7 text-emerald-600" />
          </div>
          <h2 className="text-xl font-bold">Gift card created!</h2>
          <p className="text-sm text-muted-foreground mt-1">Save these credentials — the PIN is shown only once.</p>

          <div className="mt-6 text-left space-y-3">
            <div className="p-3 rounded-lg bg-muted">
              <p className="text-xs text-muted-foreground">Card number</p>
              <p className="font-mono font-semibold text-lg">{result.card.card_number}</p>
            </div>
            <div className="p-3 rounded-lg bg-violet-50 dark:bg-violet-950/30 border border-violet-200 dark:border-violet-900">
              <p className="text-xs text-muted-foreground flex items-center gap-1"><Lock className="w-3 h-3" /> Security PIN (shown once)</p>
              <p className="font-mono font-semibold text-lg tracking-widest text-violet-700 dark:text-violet-300">{result.pin}</p>
            </div>
            <div className="p-3 rounded-lg bg-muted">
              <p className="text-xs text-muted-foreground">Balance</p>
              <p className="font-semibold text-lg">{formatMoney(result.card.balance, result.card.currency)}</p>
            </div>
          </div>

          <div className="flex gap-3 mt-6">
            <Button variant="outline" className="flex-1" onClick={() => navigate("/app/cards")}>View cards</Button>
            <Button className="flex-1" onClick={() => navigate(`/app/cards/${result.card.id}`)}>Open card</Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <PageHeader title="Create Gift Card" subtitle={isBusiness ? "Issue a new gift card" : "Create a new gift card (5 active max)"} />

      {/* Steps indicator */}
      <div className="flex items-center gap-2 mb-6 text-sm">
        {["Design", "Customize", "Done"].map((s, i) => (
          <React.Fragment key={s}>
            <div className={`flex items-center gap-2 ${step >= i + 1 ? "text-violet-600" : "text-muted-foreground"}`}>
              <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold ${step >= i + 1 ? "bg-violet-600 text-white" : "bg-muted"}`}>{i + 1}</span>
              {s}
            </div>
            {i < 2 && <div className="w-8 h-px bg-border" />}
          </React.Fragment>
        ))}
      </div>

      {/* Step 1: method */}
      {step === 1 && (
        <div className="grid md:grid-cols-3 gap-4">
          <button onClick={() => { setMethod("upload"); setStep(2); }} className="text-left rounded-2xl border bg-card p-6 hover:border-violet-500 hover:shadow-md transition-all">
            <div className="w-11 h-11 rounded-xl bg-violet-100 dark:bg-violet-900/40 flex items-center justify-center mb-3"><Upload className="w-5 h-5 text-violet-600" /></div>
            <h3 className="font-semibold">Upload your design</h3>
            <p className="text-sm text-muted-foreground mt-1">Bring finished artwork (PNG, JPG, WEBP).</p>
          </button>
          <button onClick={() => { setMethod("designer"); setStep(2); }} className="text-left rounded-2xl border bg-card p-6 hover:border-violet-500 hover:shadow-md transition-all">
            <div className="w-11 h-11 rounded-xl bg-fuchsia-100 dark:bg-fuchsia-900/40 flex items-center justify-center mb-3"><Palette className="w-5 h-5 text-fuchsia-600" /></div>
            <h3 className="font-semibold">Create your design</h3>
            <p className="text-sm text-muted-foreground mt-1">Use the drag-and-drop Card Designer.</p>
          </button>
          <button onClick={() => { setMethod("library"); setStep(2); }} className="text-left rounded-2xl border bg-card p-6 hover:border-violet-500 hover:shadow-md transition-all">
            <div className="w-11 h-11 rounded-xl bg-emerald-100 dark:bg-emerald-900/40 flex items-center justify-center mb-3"><Sparkles className="w-5 h-5 text-emerald-600" /></div>
            <h3 className="font-semibold">From design library</h3>
            <p className="text-sm text-muted-foreground mt-1">Use a saved design template.</p>
          </button>
        </div>
      )}

      {/* Step 2: design */}
      {step === 2 && (
        <div className="space-y-4">
          <Button variant="ghost" size="sm" onClick={() => setStep(1)}><ArrowLeft className="w-4 h-4 mr-1" /> Back</Button>

          {method === "upload" && (
            <div className="grid md:grid-cols-2 gap-6">
              <div className="rounded-2xl border bg-card p-5 space-y-4">
                <h3 className="font-semibold">Upload artwork</h3>
                <p className="text-xs text-muted-foreground">Recommended: 1012×638px (CR80 card ratio 1.586:1). PNG, JPG, WEBP.</p>
                <Input type="file" accept="image/png,image/jpeg,image/webp" onChange={(e) => handleUpload(e.target.files?.[0])} />
                <div>
                  <Label>Design name</Label>
                  <Input value={details.design_name} onChange={(e) => setDetails({ ...details, design_name: e.target.value })} />
                </div>
                <Button onClick={saveUploadDesign} disabled={!uploadedUrl} className="w-full">Use this design <ArrowRight className="w-4 h-4 ml-1" /></Button>
              </div>
              <div>
                {uploadedUrl ? (
                  <CardPreview design={{ front_image_url: uploadedUrl }} cardData={{ balance: formatMoney(details.value) }} />
                ) : (
                  <div className="aspect-[1.586/1] rounded-2xl border-2 border-dashed flex items-center justify-center text-muted-foreground text-sm">Preview appears here</div>
                )}
              </div>
            </div>
          )}

          {method === "designer" && (
            <CardDesigner
              businessMode={isBusiness}
              ownerId={isBusiness ? undefined : user.id}
              businessId={isBusiness ? user.data.business_id : undefined}
              onSave={onDesignerSave}
            />
          )}

          {method === "library" && (
            <div>
              {designs.length === 0 ? (
                <div className="rounded-2xl border border-dashed p-10 text-center text-muted-foreground">
                  No saved designs yet. Create one with the designer or upload artwork.
                </div>
              ) : (
                <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {designs.map((d) => (
                    <button key={d.id} onClick={() => { setDesign(d); setStep(3); }} className="text-left rounded-xl border bg-card p-3 hover:border-violet-500 hover:shadow-md transition-all">
                      <CardPreview design={d} showInfo={false} />
                      <p className="text-sm font-medium mt-2 truncate">{d.name}</p>
                      <p className="text-xs text-muted-foreground capitalize">{d.type}</p>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Step 3: details */}
      {step === 3 && (
        <div className="max-w-xl space-y-4">
          <Button variant="ghost" size="sm" onClick={() => setStep(2)}><ArrowLeft className="w-4 h-4 mr-1" /> Back to design</Button>
          <div className="rounded-2xl border bg-card p-6 space-y-4">
            <div className="flex items-center gap-2">
              <Check className="w-5 h-5 text-emerald-600" />
              <span className="font-medium">Design selected: {design?.name}</span>
            </div>
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Initial value *</Label>
                <Input type="number" min="1" value={details.value} onChange={(e) => setDetails({ ...details, value: e.target.value })} />
              </div>
              <div className="space-y-2">
                <Label>Currency</Label>
                <select value={details.currency} onChange={(e) => setDetails({ ...details, currency: e.target.value })} className="w-full h-10 rounded-md border bg-background px-3 text-sm">
                  {["USD", "EUR", "GBP", "SAR", "AED"].map((c) => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div className="space-y-2">
                <Label>Expiration date (optional)</Label>
                <Input type="date" value={details.expiration_date} onChange={(e) => setDetails({ ...details, expiration_date: e.target.value })} />
              </div>
              {isBusiness && (
                <>
                  <div className="space-y-2">
                    <Label>Program</Label>
                    <select value={details.program_id} onChange={(e) => setDetails({ ...details, program_id: e.target.value })} className="w-full h-10 rounded-md border bg-background px-3 text-sm">
                      <option value="">— None —</option>
                      {programs.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
                    </select>
                  </div>
                  <div className="space-y-2">
                    <Label>Assign to customer (optional)</Label>
                    <select value={details.customer_id} onChange={(e) => setDetails({ ...details, customer_id: e.target.value })} className="w-full h-10 rounded-md border bg-background px-3 text-sm">
                      <option value="">— Unassigned —</option>
                      {customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                  </div>
                </>
              )}
            </div>
            <Button onClick={generate} disabled={creating} className="w-full">
              {creating ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Generating card…</> : <><CreditCard className="w-4 h-4 mr-2" /> Generate gift card</>}
            </Button>
            <p className="text-xs text-muted-foreground text-center">Card number and PIN are generated with cryptographically secure randomness. The PIN is hashed before storage.</p>
          </div>
        </div>
      )}
    </div>
  );
}