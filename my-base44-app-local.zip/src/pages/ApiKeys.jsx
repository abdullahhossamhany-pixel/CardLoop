const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { useAuth } from "@/lib/AuthContext";

import { PageHeader, LoadingState, EmptyState, Badge } from "@/components/ui-parts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Code, Plus, Copy, Ban, KeyRound, Loader2, FileText } from "lucide-react";
import { generateApiKey, hashPin } from "@/lib/giftcard";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "@/components/ui/use-toast";

const EVENTS = [
  "giftcard.created", "giftcard.activated", "giftcard.redeemed", "giftcard.frozen", "giftcard.unfrozen",
  "giftcard.revoked", "giftcard.expired", "transaction.completed", "transaction.refunded",
  "physical_card.ordered", "physical_card.production", "physical_card.shipped", "physical_card.delivered",
];

export default function ApiKeys() {
  const { user } = useAuth();
  const [keys, setKeys] = useState(null);
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState("test");
  const [name, setName] = useState("");
  const [created, setCreated] = useState(null);
  const [creating, setCreating] = useState(false);

  const load = async () => { try { setKeys(await db.entities.ApiKey.filter({ business_id: user.data.business_id })); } catch { setKeys([]); } };
  useEffect(() => { load(); }, [user]);

  const create = async () => {
    setCreating(true);
    try {
      const { full, prefix } = generateApiKey(mode);
      const keyHash = await hashPin(full);
      await db.entities.ApiKey.create({
        business_id: user.data.business_id,
        key_id: "key_" + Math.random().toString(36).slice(2, 10),
        key_prefix: prefix,
        key_hash: keyHash,
        mode,
        name: name || `${mode} key`,
        status: "active",
      });
      setCreated(full);
      setOpen(false); setName(""); await load();
    } catch (e) { toast({ title: "Failed", description: e.message, variant: "destructive" }); }
    finally { setCreating(false); }
  };

  const revoke = async (k) => { try { await db.entities.ApiKey.update(k.id, { status: "revoked" }); await load(); } catch {} };

  if (keys === null) return <LoadingState />;

  return (
    <div>
      <PageHeader title="API & Developers" subtitle="Generate API keys to integrate your website or POS" actions={<Button onClick={() => setOpen(true)}><Plus className="w-4 h-4 mr-1" /> New key</Button>} />
      <div className="grid lg:grid-cols-[2fr_1fr] gap-6">
        <div>
          {keys.length === 0 ? (
            <EmptyState icon={KeyRound} title="No API keys" desc="Generate a test or production key to start integrating." action={<Button onClick={() => setOpen(true)}><Plus className="w-4 h-4 mr-1" /> New key</Button>} />
          ) : (
            <div className="rounded-2xl border bg-card overflow-hidden">
              <table className="w-full text-sm">
                <thead className="bg-muted/50 text-muted-foreground"><tr><th className="text-left font-medium px-4 py-3">Name</th><th className="text-left font-medium px-4 py-3">Key</th><th className="text-left font-medium px-4 py-3">Mode</th><th className="text-left font-medium px-4 py-3">Status</th><th></th></tr></thead>
                <tbody>
                  {keys.map((k) => (
                    <tr key={k.id} className="border-t">
                      <td className="px-4 py-3 font-medium">{k.name}</td>
                      <td className="px-4 py-3 font-mono text-xs">{k.key_prefix}…</td>
                      <td className="px-4 py-3"><span className={`px-2 py-0.5 rounded-full text-xs ${k.mode === "production" ? "bg-rose-100 text-rose-700" : "bg-amber-100 text-amber-700"}`}>{k.mode}</span></td>
                      <td className="px-4 py-3"><Badge status={k.status} /></td>
                      <td className="px-4 py-3 text-right">{k.status === "active" && <Button size="sm" variant="ghost" onClick={() => revoke(k)}><Ban className="w-3.5 h-3.5 text-rose-600" /></Button>}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
        <div className="space-y-4">
          <div className="rounded-2xl border bg-card p-5">
            <h3 className="font-semibold flex items-center gap-2 mb-2"><FileText className="w-4 h-4" /> API Documentation</h3>
            <p className="text-sm text-muted-foreground mb-3">Use your API key to create cards, check balances, redeem, refund, freeze, and revoke.</p>
            <div className="rounded-lg bg-muted p-3 text-xs font-mono overflow-x-auto">
              <pre>{`POST /api/v1/giftcards
Authorization: Bearer sk_test_...
{
  "program_id": "...",
  "value": 50,
  "currency": "USD"
}`}</pre>
            </div>
            <p className="text-xs text-amber-600 mt-3">Endpoints are integration-ready. Connect a developer backend to enable live calls.</p>
          </div>
        </div>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Generate API key</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="space-y-2"><Label>Key name</Label><Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Website checkout" /></div>
            <div className="space-y-2"><Label>Mode</Label>
              <div className="flex gap-2">
                <Button size="sm" variant={mode === "test" ? "default" : "outline"} onClick={() => setMode("test")}>Test</Button>
                <Button size="sm" variant={mode === "production" ? "default" : "outline"} onClick={() => setMode("production")}>Production</Button>
              </div>
            </div>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={create} disabled={creating}>{creating && <Loader2 className="w-4 h-4 mr-2 animate-spin" />}Generate</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      {created && (
        <Dialog open onOpenChange={() => setCreated(null)}>
          <DialogContent>
            <DialogHeader><DialogTitle>API key (shown once)</DialogTitle></DialogHeader>
            <div className="p-3 rounded-lg bg-violet-50 dark:bg-violet-950/30 border border-violet-200">
              <p className="font-mono text-sm break-all">{created}</p>
            </div>
            <p className="text-xs text-muted-foreground">Copy and store this key securely. It cannot be recovered.</p>
            <DialogFooter><Button onClick={() => { navigator.clipboard?.writeText(created); toast({ title: "Copied" }); }}>Copy key</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}