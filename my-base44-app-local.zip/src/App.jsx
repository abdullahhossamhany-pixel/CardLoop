import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import ProtectedRoute from '@/components/ProtectedRoute';
// Auth pages
import Login from '@/pages/Login';
import Register from '@/pages/Register';
import ForgotPassword from '@/pages/ForgotPassword';
import ResetPassword from '@/pages/ResetPassword';
// Public + onboarding
import Landing from '@/pages/Landing';
import Onboarding from '@/pages/Onboarding';
// Shell
import AppShell from '@/components/AppShell';
// App pages
import Dashboard from '@/pages/Dashboard';
import CardsList from '@/pages/CardsList';
import CardDetail from '@/pages/CardDetail';
import CreateCard from '@/pages/CreateCard';
import DesignerPage from '@/pages/DesignerPage';
import Transactions from '@/pages/Transactions';
import Programs from '@/pages/Programs';
import Customers from '@/pages/Customers';
import Stores from '@/pages/Stores';
import PosTerminals from '@/pages/PosTerminals';
import OnlineStores from '@/pages/OnlineStores';
import ApiKeys from '@/pages/ApiKeys';
import Webhooks from '@/pages/Webhooks';
import PhysicalCards from '@/pages/PhysicalCards';
import Verification from '@/pages/Verification';
import Billing from '@/pages/Billing';
import Settings from '@/pages/Settings';
import Analytics from '@/pages/Analytics';
import Team from '@/pages/Team';
// Admin pages
import AdminDashboard from '@/pages/admin/AdminDashboard';
import AdminUsers from '@/pages/admin/AdminUsers';
import AdminBusinesses from '@/pages/admin/AdminBusinesses';
import AdminTransactions from '@/pages/admin/AdminTransactions';
import AdminSettings from '@/pages/admin/AdminSettings';

// Guard: user must have chosen an account type
const RequireAccount = () => {
  const { user } = useAuth();
  if (!user?.data?.account_type) return <Navigate to="/onboarding" replace />;
  return <AppShell />;
};

// Guard: admin only — platform role "admin" exclusively, no self-escalation
const RequireAdmin = () => {
  const { user } = useAuth();
  if (user?.role !== "admin") return <Navigate to="/app" replace />;
  return <AppShell variant="admin" />;
};

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      navigateToLogin();
      return null;
    }
  }

  return (
    <Routes>
      {/* Auth */}
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/reset-password" element={<ResetPassword />} />
      {/* Public + onboarding */}
      <Route path="/" element={<Landing />} />
      <Route path="/onboarding" element={<Onboarding />} />

      {/* Authenticated app */}
      <Route element={<ProtectedRoute unauthenticatedElement={<Navigate to="/login" replace />} />}>
        <Route element={<RequireAccount />}>
          <Route path="/app" element={<Dashboard />} />
          <Route path="/app/cards" element={<CardsList />} />
          <Route path="/app/cards/:id" element={<CardDetail />} />
          <Route path="/app/create" element={<CreateCard />} />
          <Route path="/app/designer" element={<DesignerPage />} />
          <Route path="/app/designs" element={<DesignerPage />} />
          <Route path="/app/transactions" element={<Transactions />} />
          <Route path="/app/programs" element={<Programs />} />
          <Route path="/app/customers" element={<Customers />} />
          <Route path="/app/stores" element={<Stores />} />
          <Route path="/app/pos" element={<PosTerminals />} />
          <Route path="/app/online-stores" element={<OnlineStores />} />
          <Route path="/app/api" element={<ApiKeys />} />
          <Route path="/app/webhooks" element={<Webhooks />} />
          <Route path="/app/physical" element={<PhysicalCards />} />
          <Route path="/app/verification" element={<Verification />} />
          <Route path="/app/billing" element={<Billing />} />
          <Route path="/app/settings" element={<Settings />} />
          <Route path="/app/analytics" element={<Analytics />} />
          <Route path="/app/team" element={<Team />} />
        </Route>

        {/* Admin */}
        <Route element={<RequireAdmin />}>
          <Route path="/admin" element={<AdminDashboard />} />
          <Route path="/admin/users" element={<AdminUsers />} />
          <Route path="/admin/businesses" element={<AdminBusinesses />} />
          <Route path="/admin/giftcards" element={<CardsList />} />
          <Route path="/admin/transactions" element={<AdminTransactions />} />
          <Route path="/admin/settings" element={<AdminSettings />} />
        </Route>
      </Route>

      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};

function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App