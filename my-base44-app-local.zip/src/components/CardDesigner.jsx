const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useRef, useCallback, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Type, Image as ImageIcon, Square, Circle, Minus, Palette, Layers as LayersIcon,
  Undo2, Redo2, Trash2, Copy, ArrowUp, ArrowDown, ChevronsUp, ChevronsDown,
  Save, Plus, RotateCw, Bold, Italic, AlignLeft, AlignCenter, AlignRight,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { generateUuid } from "@/lib/giftcard";

import { toast } from "@/components/ui/use-toast";

const FONTS = [
  { label: "Sans", value: "ui-sans-serif, system-ui, sans-serif" },
  { label: "Serif", value: "ui-serif, Georgia, serif" },
  { label: "Mono", value: "ui-monospace, monospace" },
  { label: "Cursive", value: "cursive" },
];

const GRADIENTS = [
  "linear-gradient(135deg, #7c3aed, #d946ef)",
  "linear-gradient(135deg, #059669, #14b8a6)",
  "linear-gradient(135deg, #f59e0b, #f97316)",
  "linear-gradient(135deg, #dc2626, #f43f5e)",
  "linear-gradient(135deg, #2563eb, #06b6d4)",
  "linear-gradient(135deg, #1e293b, #475569)",
  "linear-gradient(135deg, #be185d, #db2777)",
];

function makeElement(type, extra = {}) {
  const base = { id: generateUuid(), type, x: 30, y: 30, w: 40, h: 12, rotation: 0, opacity: 1, z: Date.now() % 1000, ...extra };
  return base;
}

export default function CardDesigner({ initialDesign, onSave, businessMode = false, ownerId, businessId }) {
  const [side, setSide] = useState("front");
  const [frontElements, setFrontElements] = useState(initialDesign?.front_elements || []);
  const [backElements, setBackElements] = useState(initialDesign?.back_elements || []);
  const [frontBg, setFrontBg] = useState(initialDesign?.front_background || { type: "gradient", gradient: GRADIENTS[0] });
  const [backBg, setBackBg] = useState(initialDesign?.back_background || { type: "solid", color: "#1e293b" });
  const [frontImage, setFrontImage] = useState(initialDesign?.front_image_url || "");
  const [backImage, setBackImage] = useState(initialDesign?.back_image_url || "");
  const [selectedId, setSelectedId] = useState(null);
  const [name, setName] = useState(initialDesign?.name || "Untitled Design");
  const [saving, setSaving] = useState(false);

  // history (per side)
  const [history, setHistory] = useState({ front: [], back: [] });
  const [future, setFuture] = useState({ front: [], back: [] });
  const canvasRef = useRef(null);

  const elements = side === "front" ? frontElements : backElements;
  const setElements = side === "front" ? setFrontElements : setBackElements;
  const bg = side === "front" ? frontBg : backBg;
  const setBg = side === "front" ? setFrontBg : setBackBg;
  const uploadedImage = side === "front" ? frontImage : backImage;
  const setUploadedImage = side === "front" ? setFrontImage : setBackImage;

  const selected = elements.find((e) => e.id === selectedId);

  const pushHistory = useCallback(() => {
    setHistory((h) => ({
      ...h,
      [side]: [...h[side].slice(-29), { elements: JSON.parse(JSON.stringify(elements)), bg: JSON.parse(JSON.stringify(bg)) }],
    }));
    setFuture((f) => ({ ...f, [side]: [] }));
  }, [elements, bg, side]);

  const undo = () => {
    setHistory((h) => {
      const stack = h[side];
      if (!stack.length) return h;
      const prev = stack[stack.length - 1];
      setFuture((f) => ({ ...f, [side]: [{ elements: JSON.parse(JSON.stringify(elements)), bg: JSON.parse(JSON.stringify(bg)) }, ...f[side]] }));
      if (side === "front") { setFrontElements(prev.elements); setFrontBg(prev.bg); }
      else { setBackElements(prev.elements); setBackBg(prev.bg); }
      return { ...h, [side]: stack.slice(0, -1) };
    });
  };

  const redo = () => {
    setFuture((f) => {
      const stack = f[side];
      if (!stack.length) return f;
      const next = stack[0];
      setHistory((h) => ({ ...h, [side]: [...h[side], { elements: JSON.parse(JSON.stringify(elements)), bg: JSON.parse(JSON.stringify(bg)) }] }));
      if (side === "front") { setFrontElements(next.elements); setFrontBg(next.bg); }
      else { setBackElements(next.elements); setBackBg(next.bg); }
      return { ...f, [side]: stack.slice(1) };
    });
  };

  const addElement = (type) => {
    pushHistory();
    let el;
    if (type === "text") el = makeElement("text", { text: "Your text", fontSize: 18, color: "#ffffff", bold: false, italic: false, align: "left", font: FONTS[0].value, w: 45, h: 10 });
    else if (type === "image") el = makeElement("image", { src: "", w: 30, h: 30 });
    else if (type === "rect") el = makeElement("shape", { shape: "rect", fill: "#ffffff", border: "none", w: 30, h: 20 });
    else if (type === "rounded") el = makeElement("shape", { shape: "rounded", fill: "#ffffff", border: "none", w: 30, h: 20 });
    else if (type === "circle") el = makeElement("shape", { shape: "circle", fill: "#ffffff", border: "none", w: 25, h: 25 });
    else if (type === "line") el = makeElement("shape", { shape: "line", fill: "#ffffff", w: 40, h: 1.5 });
    setElements((els) => [...els, el]);
    setSelectedId(el.id);
  };

  const updateSelected = (patch) => {
    setElements((els) => els.map((e) => (e.id === selectedId ? { ...e, ...patch } : e)));
  };

  const deleteSelected = () => {
    if (!selectedId) return;
    pushHistory();
    setElements((els) => els.filter((e) => e.id !== selectedId));
    setSelectedId(null);
  };

  const duplicateSelected = () => {
    if (!selected) return;
    pushHistory();
    const copy = { ...selected, id: generateUuid(), x: selected.x + 5, y: selected.y + 5, z: Date.now() % 1000 };
    setElements((els) => [...els, copy]);
    setSelectedId(copy.id);
  };

  const reorder = (dir) => {
    if (!selectedId) return;
    pushHistory();
    setElements((els) => {
      const arr = [...els];
      const idx = arr.findIndex((e) => e.id === selectedId);
      if (idx < 0) return arr;
      const [item] = arr.splice(idx, 1);
      if (dir === "up") arr.splice(Math.min(idx + 1, arr.length), 0, item);
      else if (dir === "down") arr.splice(Math.max(idx - 1, 0), 0, item);
      else if (dir === "top") arr.push(item);
      else if (dir === "bottom") arr.unshift(item);
      return arr;
    });
  };

  // drag & resize via pointer
  const dragRef = useRef(null);
  const onPointerDown = (e, el, mode = "move") => {
    e.stopPropagation();
    e.preventDefault();
    setSelectedId(el.id);
    const canvas = canvasRef.current.getBoundingClientRect();
    dragRef.current = {
      mode,
      id: el.id,
      startX: e.clientX,
      startY: e.clientY,
      origX: el.x,
      origY: el.y,
      origW: el.w,
      origH: el.h,
      canvasW: canvas.width,
      canvasH: canvas.height,
    };
    pushHistory();
    window.addEventListener("pointermove", onPointerMove);
    window.addEventListener("pointerup", onPointerUp);
  };

  const onPointerMove = (e) => {
    const d = dragRef.current;
    if (!d) return;
    const dxPct = ((e.clientX - d.startX) / d.canvasW) * 100;
    const dyPct = ((e.clientY - d.startY) / d.canvasH) * 100;
    setElements((els) =>
      els.map((el) => {
        if (el.id !== d.id) return el;
        if (d.mode === "move") {
          return { ...el, x: Math.max(0, Math.min(95, d.origX + dxPct)), y: Math.max(0, Math.min(95, d.origY + dyPct)) };
        }
        if (d.mode === "resize") {
          return { ...el, w: Math.max(5, d.origW + dxPct), h: Math.max(2, d.origH + dyPct) };
        }
        return el;
      })
    );
  };

  const onPointerUp = () => {
    dragRef.current = null;
    window.removeEventListener("pointermove", onPointerMove);
    window.removeEventListener("pointerup", onPointerUp);
  };

  useEffect(() => () => {
    window.removeEventListener("pointermove", onPointerMove);
    window.removeEventListener("pointerup", onPointerUp);
  }, []);

  const handleImageUpload = async (file) => {
    if (!file) return;
    try {
      const { file_url } = await db.integrations.Core.UploadPublicFile({ file });
      setUploadedImage(file_url);
      toast({ title: "Image uploaded" });
    } catch (e) {
      toast({ title: "Upload failed", description: e.message, variant: "destructive" });
    }
  };

  const handleElementImage = async (file) => {
    if (!file) return;
    try {
      const { file_url } = await db.integrations.Core.UploadPublicFile({ file });
      updateSelected({ src: file_url });
    } catch (e) {
      toast({ title: "Upload failed", description: e.message, variant: "destructive" });
    }
  };

  const save = async () => {
    setSaving(true);
    try {
      const payload = {
        name,
        type: "designer",
        owner_id: ownerId || undefined,
        business_id: businessId || undefined,
        front_elements: frontElements,
        back_elements: backElements,
        front_background: frontBg,
        back_background: backBg,
        front_image_url: frontImage,
        back_image_url: backImage,
      };
      let saved;
      if (initialDesign?.id) {
        saved = await db.entities.GiftCardDesign.update(initialDesign.id, payload);
      } else {
        saved = await db.entities.GiftCardDesign.create(payload);
      }
      toast({ title: "Design saved", description: name });
      onSave?.(saved);
    } catch (e) {
      toast({ title: "Save failed", description: e.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const bgStyle = {};
  if (bg.type === "solid" && bg.color) bgStyle.background = bg.color;
  else if (bg.type === "gradient" && bg.gradient) bgStyle.background = bg.gradient;
  else if (bg.type === "image" && bg.image) bgStyle.backgroundImage = `url(${bg.image})`;
  else bgStyle.background = GRADIENTS[0];

  return (
    <div className="grid lg:grid-cols-[1fr_300px] gap-4">
      {/* Editor area */}
      <div className="space-y-3">
        {/* Toolbar */}
        <div className="flex flex-wrap items-center gap-2 p-2 rounded-xl border bg-card">
          <Button size="sm" variant="outline" onClick={() => addElement("text")}><Type className="w-4 h-4 mr-1" /> Text</Button>
          <Button size="sm" variant="outline" onClick={() => addElement("image")}><ImageIcon className="w-4 h-4 mr-1" /> Image</Button>
          <Button size="sm" variant="outline" onClick={() => addElement("rect")}><Square className="w-4 h-4 mr-1" /> Rect</Button>
          <Button size="sm" variant="outline" onClick={() => addElement("rounded")}><Square className="w-4 h-4 mr-1" /> Rounded</Button>
          <Button size="sm" variant="outline" onClick={() => addElement("circle")}><Circle className="w-4 h-4 mr-1" /> Circle</Button>
          <Button size="sm" variant="outline" onClick={() => addElement("line")}><Minus className="w-4 h-4 mr-1" /> Line</Button>
          <div className="w-px h-6 bg-border mx-1" />
          <Button size="sm" variant="ghost" onClick={undo} title="Undo"><Undo2 className="w-4 h-4" /></Button>
          <Button size="sm" variant="ghost" onClick={redo} title="Redo"><Redo2 className="w-4 h-4" /></Button>
          <div className="flex-1" />
          {businessMode && (
            <div className="flex rounded-lg border overflow-hidden">
              <Button size="sm" variant={side === "front" ? "default" : "ghost"} onClick={() => { setSide("front"); setSelectedId(null); }}>Front</Button>
              <Button size="sm" variant={side === "back" ? "default" : "ghost"} onClick={() => { setSide("back"); setSelectedId(null); }}>Back</Button>
            </div>
          )}
          <Button size="sm" onClick={save} disabled={saving}><Save className="w-4 h-4 mr-1" /> Save</Button>
        </div>

        {/* Canvas */}
        <div className="flex justify-center">
          <div
            ref={canvasRef}
            className="relative w-full max-w-md aspect-[1.586/1] rounded-2xl overflow-hidden shadow-xl border"
            style={bgStyle}
            onPointerDown={() => setSelectedId(null)}
          >
            {bg.type === "image" && bg.image && <img src={bg.image} alt="" className="absolute inset-0 w-full h-full object-cover pointer-events-none" />}
            {uploadedImage && <img src={uploadedImage} alt="" className="absolute inset-0 w-full h-full object-cover pointer-events-none" />}
            {elements.map((el) => {
              const isSel = el.id === selectedId;
              const style = {
                position: "absolute",
                left: `${el.x}%`,
                top: `${el.y}%`,
                width: `${el.w}%`,
                height: `${el.h}%`,
                transform: `rotate(${el.rotation || 0}deg)`,
                opacity: el.opacity != null ? el.opacity : 1,
                zIndex: elements.indexOf(el),
                cursor: "move",
                outline: isSel ? "2px solid #7c3aed" : "none",
                outlineOffset: isSel ? "2px" : "0",
              };
              return (
                <div key={el.id} style={style} onPointerDown={(e) => onPointerDown(e, el, "move")}>
                  {el.type === "text" && (
                    <div
                      style={{
                        width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: el.align === "center" ? "center" : el.align === "right" ? "flex-end" : "flex-start",
                        color: el.color, fontSize: `${el.fontSize}px`, fontWeight: el.bold ? 700 : 400, fontStyle: el.italic ? "italic" : "normal",
                        textAlign: el.align, letterSpacing: `${el.letterSpacing || 0}px`, fontFamily: el.font, overflow: "hidden", wordBreak: "break-word",
                      }}
                    >
                      {el.text}
                    </div>
                  )}
                  {el.type === "image" && el.src && (
                    <img src={el.src} alt="" style={{ width: "100%", height: "100%", objectFit: "cover", borderRadius: el.borderRadius || 0 }} draggable={false} />
                  )}
                  {el.type === "shape" && (
                    <div
                      style={{
                        width: "100%", height: el.shape === "line" ? "100%" : "100%", background: el.fill, border: el.border || "none",
                        borderRadius: el.shape === "circle" ? "9999px" : el.shape === "rounded" ? "12px" : "0",
                      }}
                    />
                  )}
                  {isSel && (
                    <>
                      <div
                        onPointerDown={(e) => onPointerDown(e, el, "resize")}
                        className="absolute -bottom-1 -right-1 w-3 h-3 bg-violet-600 rounded-sm border-2 border-white cursor-nwse-resize"
                      />
                      <div
                        onPointerDown={(e) => { e.stopPropagation(); const cur = el.rotation || 0; const newVal = prompt("Rotation degrees:", cur); if (newVal != null) updateSelected({ rotation: parseFloat(newVal) || 0 }); }}
                        className="absolute -top-6 left-1/2 -translate-x-1/2 w-5 h-5 bg-violet-600 rounded-full border-2 border-white flex items-center justify-center cursor-pointer"
                      >
                        <RotateCw className="w-2.5 h-2.5 text-white" />
                      </div>
                    </>
                  )}
                </div>
              );
            })}
          </div>
        </div>
        <p className="text-center text-xs text-muted-foreground">Card aspect ratio 1.586:1 (CR80). Drag to move, corner handle to resize, top handle to rotate.</p>
      </div>

      {/* Right panel */}
      <div className="space-y-4">
        {/* Properties */}
        <div className="rounded-xl border bg-card p-3 space-y-3">
          <h3 className="font-semibold text-sm flex items-center gap-2"><Palette className="w-4 h-4" /> Properties</h3>
          {!selected ? (
            <>
              <Label className="text-xs">Background</Label>
              <div className="flex gap-2">
                <Button size="sm" variant={bg.type === "solid" ? "default" : "outline"} onClick={() => setBg({ ...bg, type: "solid" })}>Solid</Button>
                <Button size="sm" variant={bg.type === "gradient" ? "default" : "outline"} onClick={() => setBg({ ...bg, type: "gradient" })}>Gradient</Button>
                <Button size="sm" variant={bg.type === "image" ? "default" : "outline"} onClick={() => setBg({ ...bg, type: "image" })}>Image</Button>
              </div>
              {bg.type === "solid" && (
                <Input type="color" value={bg.color || "#7c3aed"} onChange={(e) => setBg({ ...bg, color: e.target.value })} className="h-10 p-1" />
              )}
              {bg.type === "gradient" && (
                <div className="grid grid-cols-4 gap-2">
                  {GRADIENTS.map((g) => (
                    <button key={g} onClick={() => setBg({ ...bg, gradient: g })} className="h-10 rounded-lg border" style={{ background: g }} />
                  ))}
                </div>
              )}
              {bg.type === "image" && (
                <div>
                  <Input type="file" accept="image/*" onChange={(e) => handleImageUpload(e.target.files?.[0])} className="text-xs" />
                  {bg.image && <img src={bg.image} alt="" className="mt-2 h-16 w-full object-cover rounded" />}
                </div>
              )}
              <div className="pt-2 border-t">
                <Label className="text-xs">Upload full-bleed artwork (overrides background)</Label>
                <Input type="file" accept="image/png,image/jpeg,image/webp" onChange={(e) => handleImageUpload(e.target.files?.[0])} className="text-xs" />
                {uploadedImage && <p className="text-xs text-emerald-600 mt-1">Artwork set</p>}
              </div>
            </>
          ) : (
            <>
              <div className="flex gap-2 flex-wrap">
                <Button size="sm" variant="outline" onClick={duplicateSelected}><Copy className="w-3.5 h-3.5" /></Button>
                <Button size="sm" variant="outline" onClick={deleteSelected}><Trash2 className="w-3.5 h-3.5" /></Button>
                <Button size="sm" variant="outline" onClick={() => reorder("up")} title="Bring forward"><ArrowUp className="w-3.5 h-3.5" /></Button>
                <Button size="sm" variant="outline" onClick={() => reorder("down")} title="Send backward"><ArrowDown className="w-3.5 h-3.5" /></Button>
                <Button size="sm" variant="outline" onClick={() => reorder("top")} title="Bring to front"><ChevronsUp className="w-3.5 h-3.5" /></Button>
                <Button size="sm" variant="outline" onClick={() => reorder("bottom")} title="Send to back"><ChevronsDown className="w-3.5 h-3.5" /></Button>
              </div>

              {selected.type === "text" && (
                <div className="space-y-2">
                  <Textarea value={selected.text} onChange={(e) => updateSelected({ text: e.target.value })} rows={2} className="text-sm" />
                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label className="text-xs">Font</Label>
                      <select value={selected.font} onChange={(e) => updateSelected({ font: e.target.value })} className="w-full h-9 rounded-md border bg-background text-sm px-2">
                        {FONTS.map((f) => <option key={f.value} value={f.value}>{f.label}</option>)}
                      </select>
                    </div>
                    <div>
                      <Label className="text-xs">Size</Label>
                      <Input type="number" value={selected.fontSize} onChange={(e) => updateSelected({ fontSize: parseInt(e.target.value) || 16 })} className="h-9" />
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button size="sm" variant={selected.bold ? "default" : "outline"} onClick={() => updateSelected({ bold: !selected.bold })}><Bold className="w-3.5 h-3.5" /></Button>
                    <Button size="sm" variant={selected.italic ? "default" : "outline"} onClick={() => updateSelected({ italic: !selected.italic })}><Italic className="w-3.5 h-3.5" /></Button>
                    <Button size="sm" variant={selected.align === "left" ? "default" : "outline"} onClick={() => updateSelected({ align: "left" })}><AlignLeft className="w-3.5 h-3.5" /></Button>
                    <Button size="sm" variant={selected.align === "center" ? "default" : "outline"} onClick={() => updateSelected({ align: "center" })}><AlignCenter className="w-3.5 h-3.5" /></Button>
                    <Button size="sm" variant={selected.align === "right" ? "default" : "outline"} onClick={() => updateSelected({ align: "right" })}><AlignRight className="w-3.5 h-3.5" /></Button>
                  </div>
                  <div className="flex items-center gap-2">
                    <Label className="text-xs">Color</Label>
                    <Input type="color" value={selected.color || "#ffffff"} onChange={(e) => updateSelected({ color: e.target.value })} className="h-8 w-12 p-1" />
                    <Label className="text-xs">Opacity</Label>
                    <Input type="range" min="0" max="1" step="0.1" value={selected.opacity} onChange={(e) => updateSelected({ opacity: parseFloat(e.target.value) })} className="flex-1" />
                  </div>
                  <div>
                    <Label className="text-xs">Letter spacing</Label>
                    <Input type="number" value={selected.letterSpacing || 0} onChange={(e) => updateSelected({ letterSpacing: parseFloat(e.target.value) || 0 })} className="h-9" />
                  </div>
                </div>
              )}
              {selected.type === "image" && (
                <div className="space-y-2">
                  <Input type="file" accept="image/*" onChange={(e) => handleElementImage(e.target.files?.[0])} className="text-xs" />
                  {selected.src && <img src={selected.src} alt="" className="h-20 w-full object-cover rounded" />}
                  <div>
                    <Label className="text-xs">Opacity</Label>
                    <Input type="range" min="0" max="1" step="0.1" value={selected.opacity} onChange={(e) => updateSelected({ opacity: parseFloat(e.target.value) })} />
                  </div>
                </div>
              )}
              {selected.type === "shape" && (
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Label className="text-xs">Fill</Label>
                    <Input type="color" value={selected.fill || "#ffffff"} onChange={(e) => updateSelected({ fill: e.target.value })} className="h-8 w-12 p-1" />
                    <Label className="text-xs">Opacity</Label>
                    <Input type="range" min="0" max="1" step="0.1" value={selected.opacity} onChange={(e) => updateSelected({ opacity: parseFloat(e.target.value) })} className="flex-1" />
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Layers */}
        <div className="rounded-xl border bg-card p-3">
          <h3 className="font-semibold text-sm flex items-center gap-2 mb-2"><LayersIcon className="w-4 h-4" /> Layers</h3>
          <div className="space-y-1 max-h-64 overflow-y-auto">
            {[...elements].reverse().map((el) => (
              <button
                key={el.id}
                onClick={() => setSelectedId(el.id)}
                className={cn(
                  "w-full flex items-center gap-2 px-2 py-1.5 rounded-md text-xs text-left",
                  el.id === selectedId ? "bg-violet-100 dark:bg-violet-900/40" : "hover:bg-muted"
                )}
              >
                {el.type === "text" && <Type className="w-3.5 h-3.5" />}
                {el.type === "image" && <ImageIcon className="w-3.5 h-3.5" />}
                {el.type === "shape" && <Square className="w-3.5 h-3.5" />}
                <span className="truncate">{el.type === "text" ? el.text?.slice(0, 18) : el.type}</span>
              </button>
            ))}
            {elements.length === 0 && <p className="text-xs text-muted-foreground px-2">No layers yet</p>}
          </div>
        </div>

        <div className="rounded-xl border bg-card p-3">
          <Label className="text-xs">Design name</Label>
          <Input value={name} onChange={(e) => setName(e.target.value)} className="h-9" />
        </div>
      </div>
    </div>
  );
}