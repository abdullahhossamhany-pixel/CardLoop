const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";

import { PageHeader, Badge, LoadingState, EmptyState } from "@/components/ui-parts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import CardPreview from "@/components/CardPreview";
import { formatMoney, generateTxnId } from "@/lib/giftcard";
import { toast } from "@/components/ui/use-toast";
import {
  Snowflake, Play, Trash2, Ban, ArrowDownLeft, ArrowUpRight, ShieldAlert, Copy,
  CreditCard, Loader2,
} from "lucide-react";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function CardDetail() {
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [card, setCard] = useState(null);
  const [design, setDesign] = useState(null);
  const [txns, setTxns] = useState(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [redeemAmt, setRedeemAmt] = useState("");
  const [loadAmt, setLoadAmt] = useState("");

  const load = async () => {
    try {
      const c = await db.entities.GiftCard.get(id);
      setCard(c);
      if (c.design_id) {
        try { setDesign(await db.entities.GiftCardDesign.get(c.design_id)); } catch {}
      }
      const t = await db.entities.Transaction.filter({ gift_card_id: id }, "-created_date");
      setTxns(t);
    } catch (e) {
      toast({ title: "Card not found", variant: "destructive" });
      navigate("/app/cards");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [id]);

  const refresh = async () => {
    const c = await db.entities.GiftCard.get(id);
    setCard(c);
    setTxns(await db.entities.Transaction.filter({ gift_card_id: id }, "-created_date"));
  };

  const setStatus = async (status, extra = {}) => {
    setBusy(true);
    try {
      await db.entities.GiftCard.update(id, { status, ...extra });
      await refresh();
      toast({ title: `Card ${status}` });
    } catch (e) {
      toast({ title: "Failed", description: e.message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const deleteCard = async () => {
    setBusy(true);
    try {
      await db.entities.GiftCard.update(id, { status: "deleted", deleted_at: new Date().toISOString() });
      toast({ title: "Card permanently deleted", description: "This card can never be restored or reused." });
      navigate("/app/cards");
    } catch (e) {
      toast({ title: "Failed", description: e.message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const doRedeem = async () => {
    const amt = Number(redeemAmt);
    if (!amt || amt <= 0) { toast({ title: "Enter an amount", variant: "destructive" }); return; }
    if (card.status !== "active") { toast({ title: "Card not active", variant: "destructive" }); return; }
    if (amt > card.balance) { toast({ title: "Insufficient balance", variant: "destructive" }); return; }
    setBusy(true);
    try {
      const newBal = card.balance - amt;
      await db.entities.GiftCard.update(id, { balance: newBal });
      await db.entities.Transaction.create({
        transaction_id: generateTxnId(),
        gift_card_id: id,
        business_id: card.business_id || undefined,
        type: "redeem",
        amount: amt,
        currency: card.currency,
        previous_balance: card.balance,
        new_balance: newBal,
        status: "completed",
        is_test_data: false,
      });
      setRedeemAmt("");
      await refresh();
      toast({ title: "Approved", description: `Remaining balance: ${formatMoney(newBal, card.currency)}` });
    } catch (e) {
      toast({ title: "Declined", description: e.message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  const doLoad = async () => {
    const amt = Number(loadAmt);
    if (!amt || amt <= 0) { toast({ title: "Enter an amount", variant: "destructive" }); return; }
    if (card.status !== "active") { toast({ title: "Card not active", variant: "destructive" }); return; }
    setBusy(true);
    try {
      const newBal = card.balance + amt;
      await db.entities.GiftCard.update(id, { balance: newBal });
      await db.entities.Transaction.create({
        transaction_id: generateTxnId(),
        gift_card_id: id,
        business_id: card.business_id || undefined,
        type: "load",
        amount: amt,
        currency: card.currency,
        previous_balance: card.balance,
        new_balance: newBal,
        status: "completed",
        is_test_data: false,
      });
      setLoadAmt("");
      await refresh();
      toast({ title: "Funds loaded" });
    } catch (e) {
      toast({ title: "Failed", description: e.message, variant: "destructive" });
    } finally {
      setBusy(false);
    }
  };

  if (loading) return <LoadingState />;
  if (!card) return null;

  const isDeleted = card.status === "deleted";

  return (
    <div>
      <PageHeader
        title={card.card_number}
        subtitle={isDeleted ? "This card has been permanently deleted" : `${formatMoney(card.balance, card.currency)} balance`}
        actions={<Link to="/app/cards"><Button variant="outline" size="sm">Back to cards</Button></Link>}
      />

      <div className="grid lg:grid-cols-[1fr_2fr] gap-6">
        {/* Left: card preview + actions */}
        <div className="space-y-4">
          <CardPreview
            design={design || {}}
            cardData={{
              card_number: card.card_number,
              balance: formatMoney(card.balance, card.currency),
              business_name: card.business_id ? "Business" : "GiftLoop",
              expiration_date: card.expiration_date,
            }}
          />
          <div className="rounded-2xl border bg-card p-4 space-y-3 text-sm">
            <div className="flex justify-between"><span className="text-muted-foreground">Status</span><Badge status={card.status} /></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Initial value</span><span>{formatMoney(card.initial_value, card.currency)}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">Currency</span><span>{card.currency}</span></div>
            {card.expiration_date && <div className="flex justify-between"><span className="text-muted-foreground">Expires</span><span>{new Date(card.expiration_date).toLocaleDateString()}</span></div>}
            <div className="flex justify-between"><span className="text-muted-foreground">Created</span><span>{new Date(card.created_date).toLocaleDateString()}</span></div>
            <div className="flex justify-between"><span className="text-muted-foreground">UUID</span><span className="font-mono text-xs truncate max-w-[140px]">{card.card_uuid}</span></div>
          </div>

          {!isDeleted && (
            <div className="rounded-2xl border bg-card p-4 space-y-2">
              <p className="text-sm font-semibold mb-1">Card controls</p>
              {card.status === "active" && (
                <Button variant="outline" size="sm" className="w-full justify-start" disabled={busy} onClick={() => setStatus("frozen")}>
                  <Snowflake className="w-4 h-4 mr-2" /> Freeze card
                </Button>
              )}
              {card.status === "frozen" && (
                <Button variant="outline" size="sm" className="w-full justify-start" disabled={busy} onClick={() => setStatus("active")}>
                  <Play className="w-4 h-4 mr-2" /> Unfreeze card
                </Button>
              )}
              {user?.data?.account_type === "business" && card.status !== "revoked" && (
                <Button variant="outline" size="sm" className="w-full justify-start text-amber-600" disabled={busy} onClick={() => setStatus("revoked")}>
                  <Ban className="w-4 h-4 mr-2" /> Revoke card
                </Button>
              )}
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="outline" size="sm" className="w-full justify-start text-rose-600" disabled={busy}>
                    <Trash2 className="w-4 h-4 mr-2" /> Permanently delete
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent>
                  <AlertDialogHeader>
                    <AlertDialogTitle>Delete this gift card?</AlertDialogTitle>
                    <AlertDialogDescription>
                    This permanently invalidates the card. It cannot be restored, used, or process transactions. The card number will never be reused. Balance and transaction records are kept for audit.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={deleteCard} className="bg-rose-600 hover:bg-rose-700">Delete permanently</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          )}
        </div>

        {/* Right: balance ops + transactions */}
        <div className="space-y-6">
          {!isDeleted && (
            <div className="grid sm:grid-cols-2 gap-4">
              <div className="rounded-2xl border bg-card p-4 space-y-3">
                <p className="text-sm font-semibold flex items-center gap-2"><ArrowUpRight className="w-4 h-4 text-rose-600" /> Redeem (test)</p>
                <p className="text-xs text-muted-foreground">Simulate a redemption. Backend checks balance & status.</p>
                <div className="flex gap-2">
                  <Input type="number" placeholder="Amount" value={redeemAmt} onChange={(e) => setRedeemAmt(e.target.value)} />
                  <Button onClick={doRedeem} disabled={busy}>Redeem</Button>
                </div>
              </div>
              <div className="rounded-2xl border bg-card p-4 space-y-3">
                <p className="text-sm font-semibold flex items-center gap-2"><ArrowDownLeft className="w-4 h-4 text-emerald-600" /> Load funds</p>
                <p className="text-xs text-muted-foreground">Add to the card balance.</p>
                <div className="flex gap-2">
                  <Input type="number" placeholder="Amount" value={loadAmt} onChange={(e) => setLoadAmt(e.target.value)} />
                  <Button onClick={doLoad} disabled={busy}>Load</Button>
                </div>
              </div>
            </div>
          )}

          <div className="rounded-2xl border bg-card p-5">
            <h2 className="font-semibold mb-4">Transaction history</h2>
            {(!txns || txns.length === 0) ? (
              <EmptyState icon={CreditCard} title="No transactions" desc="Transactions will appear here once the card is used." />
            ) : (
              <div className="space-y-2">
                {txns.map((t) => (
                  <div key={t.id} className="flex items-center justify-between p-3 rounded-lg hover:bg-muted">
                    <div className="flex items-center gap-3">
                      <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${t.type === "redeem" ? "bg-rose-100 text-rose-600 dark:bg-rose-900/40" : "bg-emerald-100 text-emerald-600 dark:bg-emerald-900/40"}`}>
                        {t.type === "redeem" ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownLeft className="w-4 h-4" />}
                      </div>
                      <div>
                        <p className="text-sm font-medium capitalize">{t.type}</p>
                        <p className="text-xs text-muted-foreground">{new Date(t.created_date).toLocaleString()}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`text-sm font-semibold ${t.type === "redeem" ? "text-rose-600" : "text-emerald-600"}`}>{t.type === "redeem" ? "-" : "+"}{formatMoney(t.amount, t.currency)}</p>
                      <p className="text-xs text-muted-foreground">Bal: {formatMoney(t.new_balance, t.currency)}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}