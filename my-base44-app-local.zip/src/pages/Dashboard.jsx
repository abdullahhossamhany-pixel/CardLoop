const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";

import { PageHeader, StatCard, Badge, LoadingState, EmptyState } from "@/components/ui-parts";
import { useBusiness, useTrialStatus } from "@/lib/useBusiness";
import { formatMoney, daysBetween } from "@/lib/giftcard";
import { Button } from "@/components/ui/button";
import {
  CreditCard, Snowflake, Wallet, Receipt, Store, ShoppingBag, Code, Plus,
  Sparkles, TrendingUp, AlertCircle, Gift,
} from "lucide-react";

export default function Dashboard() {
  const { user } = useAuth();
  const isBusiness = user?.data?.account_type === "business";
  const { business } = useBusiness();
  const trial = useTrialStatus(business);
  const [cards, setCards] = useState(null);
  const [txns, setTxns] = useState(null);
  const [stores, setStores] = useState([]);
  const [pos, setPos] = useState([]);
  const [online, setOnline] = useState([]);

  useEffect(() => {
    (async () => {
      try {
        if (isBusiness) {
          const bid = user.data.business_id;
          const [c, t, s, p, o] = await Promise.all([
            db.entities.GiftCard.filter({ business_id: bid }),
            db.entities.Transaction.filter({ business_id: bid }, "-created_date", 10),
            db.entities.Store.filter({ business_id: bid }),
            db.entities.PosTerminal.filter({ business_id: bid }),
            db.entities.OnlineStoreIntegration.filter({ business_id: bid }),
          ]);
          setCards(c); setTxns(t); setStores(s); setPos(p); setOnline(o);
        } else {
          const [c, t] = await Promise.all([
            db.entities.GiftCard.filter({ owner_id: user.id, owner_type: "user" }),
            db.entities.Transaction.filter({}, "-created_date", 10),
          ]);
          setCards(c); setTxns(t);
        }
      } catch (e) {
        console.error(e);
      }
    })();
  }, [user, isBusiness]);

  if (cards === null) return <LoadingState />;

  const activeCards = cards.filter((c) => c.status === "active");
  const frozenCards = cards.filter((c) => c.status === "frozen");
  const totalBalance = cards.filter((c) => c.status !== "deleted").reduce((s, c) => s + (c.balance || 0), 0);
  const txnsToday = (txns || []).filter((t) => new Date(t.created_date).toDateString() === new Date().toDateString());

  return (
    <div>
      <PageHeader
        title={isBusiness ? `Welcome, ${business?.display_name || "Business"}` : `Welcome back`}
        subtitle={isBusiness ? "Business overview" : "Your gift card wallet"}
        actions={<Link to="/app/create"><Button><Plus className="w-4 h-4 mr-1" /> New Card</Button></Link>}
      />

      {/* Business trial banner */}
      {isBusiness && business && (
        <div className="rounded-2xl bg-gradient-to-r from-violet-600 to-fuchsia-600 p-5 text-white mb-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <p className="font-semibold text-lg flex items-center gap-2"><Sparkles className="w-5 h-5" /> Full Business Trial</p>
              <p className="text-sm opacity-90 mt-0.5">
                {trial.expired ? "Your trial has expired. Subscribe to continue using business management features."
                  : `${trial.daysLeft} days remaining — no credit card required.`}
              </p>
            </div>
            <div className="text-sm opacity-90">
              <p>Started: {new Date(business.trial_start_date).toLocaleDateString()}</p>
              <p>Expires: {new Date(business.trial_end_date).toLocaleDateString()}</p>
            </div>
          </div>
          {trial.expired && (
            <Link to="/app/billing"><Button variant="secondary" size="sm" className="mt-3">Subscribe now</Button></Link>
          )}
        </div>
      )}

      {/* Personal 5-card note */}
      {!isBusiness && (
        <div className="rounded-2xl border bg-card p-4 mb-6 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-emerald-100 dark:bg-emerald-900/40 flex items-center justify-center">
            <Gift className="w-5 h-5 text-emerald-600 dark:text-emerald-300" />
          </div>
          <div className="flex-1">
            <p className="font-medium text-sm">Personal plan — free forever</p>
            <p className="text-xs text-muted-foreground">You can have up to 5 active gift cards. You currently have {activeCards.length} active.</p>
          </div>
          <div className="text-2xl font-bold">{activeCards.length}<span className="text-muted-foreground text-base">/5</span></div>
        </div>
      )}

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Active cards" value={activeCards.length} icon={CreditCard} tone="emerald" />
        <StatCard label="Frozen cards" value={frozenCards.length} icon={Snowflake} tone="blue" />
        <StatCard label={isBusiness ? "Outstanding balance" : "Total balance"} value={formatMoney(totalBalance)} icon={Wallet} tone="violet" />
        <StatCard label="Transactions today" value={txnsToday.length} icon={Receipt} tone="amber" />
      </div>

      {isBusiness && (
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          <StatCard label="Physical stores" value={stores.length} icon={Store} tone="zinc" />
          <StatCard label="POS terminals" value={pos.length} icon={CreditCard} tone="zinc" />
          <StatCard label="Online stores" value={online.length} icon={ShoppingBag} tone="zinc" />
          <StatCard label="Cards created" value={cards.length} icon={TrendingUp} tone="zinc" />
        </div>
      )}

      {/* Recent cards */}
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="rounded-2xl border bg-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">Recent cards</h2>
            <Link to="/app/cards" className="text-sm text-violet-600 hover:underline">View all</Link>
          </div>
          {cards.length === 0 ? (
            <EmptyState icon={CreditCard} title="No cards yet" desc="Create your first gift card." action={<Link to="/app/create"><Button size="sm"><Plus className="w-4 h-4 mr-1" /> Create card</Button></Link>} />
          ) : (
            <div className="space-y-2">
              {cards.slice(0, 5).map((c) => (
                <Link key={c.id} to={`/app/cards/${c.id}`} className="flex items-center justify-between p-3 rounded-lg hover:bg-muted transition-colors">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-violet-500 to-fuchsia-500 flex items-center justify-center"><CreditCard className="w-4 h-4 text-white" /></div>
                    <div>
                      <p className="text-sm font-medium font-mono">{c.card_number}</p>
                      <p className="text-xs text-muted-foreground">{formatMoney(c.balance, c.currency)}</p>
                    </div>
                  </div>
                  <Badge status={c.status} />
                </Link>
              ))}
            </div>
          )}
        </div>

        <div className="rounded-2xl border bg-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold">Recent transactions</h2>
          </div>
          {(txns || []).length === 0 ? (
            <EmptyState icon={Receipt} title="No transactions yet" desc="Transactions will appear here." />
          ) : (
            <div className="space-y-2">
              {txns.slice(0, 6).map((t) => (
                <div key={t.id} className="flex items-center justify-between p-3 rounded-lg hover:bg-muted">
                  <div className="flex items-center gap-3">
                    <div className={`w-9 h-9 rounded-lg flex items-center justify-center ${t.type === "redeem" ? "bg-rose-100 text-rose-600 dark:bg-rose-900/40" : "bg-emerald-100 text-emerald-600 dark:bg-emerald-900/40"}`}>
                      <Receipt className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="text-sm font-medium capitalize">{t.type}</p>
                      <p className="text-xs text-muted-foreground">{new Date(t.created_date).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <span className={`text-sm font-semibold ${t.type === "redeem" ? "text-rose-600" : "text-emerald-600"}`}>
                    {t.type === "redeem" ? "-" : "+"}{formatMoney(t.amount, t.currency)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}