const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";

import { PageHeader, LoadingState, Badge } from "@/components/ui-parts";

export default function AdminUsers() {
  const [users, setUsers] = useState(null);
  useEffect(() => { (async () => { try { setUsers(await db.entities.User.list()); } catch { setUsers([]); } })(); }, []);
  if (!users) return <LoadingState />;
  return (
    <div>
      <PageHeader title="Users" subtitle="All platform users" />
      <div className="rounded-2xl border bg-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted/50 text-muted-foreground"><tr><th className="text-left font-medium px-4 py-3">Name</th><th className="text-left font-medium px-4 py-3">Email</th><th className="text-left font-medium px-4 py-3">Account</th><th className="text-left font-medium px-4 py-3">Role</th></tr></thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id} className="border-t">
                <td className="px-4 py-3 font-medium">{u.full_name || "—"}</td>
                <td className="px-4 py-3 text-muted-foreground">{u.email}</td>
                <td className="px-4 py-3 capitalize">{u.data?.account_type || "personal"}</td>
                <td className="px-4 py-3 capitalize">{u.role}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}