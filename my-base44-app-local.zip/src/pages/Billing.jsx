const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { useAuth } from "@/lib/AuthContext";

import { PageHeader, LoadingState, Badge, NotConfiguredBanner } from "@/components/ui-parts";
import { Button } from "@/components/ui/button";
import { useBusiness, useTrialStatus } from "@/lib/useBusiness";
import { Receipt, Check, Sparkles, CreditCard } from "lucide-react";
import { toast } from "@/components/ui/use-toast";

export default function Billing() {
  const { user } = useAuth();
  const { business, reload } = useBusiness();
  const trial = useTrialStatus(business);
  const [sub, setSub] = useState(null);

  useEffect(() => {
    (async () => {
      if (!user?.data?.business_id) return;
      try { setSub(await db.entities.Subscription.filter({ business_id: user.data.business_id })); } catch {}
    })();
  }, [user]);

  if (!business) return <LoadingState />;

  const subscribe = async () => {
    try {
      await db.entities.Business.update(business.id, { subscription_status: "active" });
      await reload();
      toast({ title: "Subscription activated", description: "Business management features are now active." });
    } catch (e) { toast({ title: "Failed", description: e.message, variant: "destructive" }); }
  };

  return (
    <div>
      <PageHeader title="Billing" subtitle="Your plan and subscription" />
      <div className="rounded-2xl bg-gradient-to-r from-violet-600 to-fuchsia-600 p-6 text-white mb-6">
        <div className="flex items-center gap-2 mb-1"><Sparkles className="w-5 h-5" /> <span className="font-semibold text-lg">Full Business Trial</span></div>
        <p className="text-sm opacity-90">
          {trial.expired ? "Your trial has expired." : `${trial.daysLeft} days remaining of your 6-month full trial.`}
        </p>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 mt-4 text-sm">
          <div><p className="opacity-70 text-xs">Started</p><p className="font-medium">{new Date(business.trial_start_date).toLocaleDateString()}</p></div>
          <div><p className="opacity-70 text-xs">Expires</p><p className="font-medium">{new Date(business.trial_end_date).toLocaleDateString()}</p></div>
          <div><p className="opacity-70 text-xs">Status</p><p className="font-medium capitalize">{business.subscription_status}</p></div>
        </div>
      </div>

      <NotConfiguredBanner title="Payment provider (NOW Payments) not configured" desc="The billing architecture is provider-independent and ready. A platform admin must add the NOW Payments API key in the Admin Console → Settings before live payments can be processed. No card details are ever stored on our servers." />

      <div className="grid sm:grid-cols-2 gap-4 mt-6">
        <div className="rounded-2xl border bg-card p-6">
          <h3 className="font-semibold mb-3">Business plan</h3>
          <p className="text-3xl font-bold">$49<span className="text-base font-normal text-muted-foreground">/month</span></p>
          <ul className="mt-4 space-y-2 text-sm">
            {["Unlimited gift cards", "All integrations", "API & webhooks", "Physical NFC cards", "Team & analytics"].map((f) => (
              <li key={f} className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-500" /> {f}</li>
            ))}
          </ul>
          <Button className="w-full mt-5" onClick={subscribe} disabled={business.subscription_status === "active"}>
            {business.subscription_status === "active" ? "Active" : "Subscribe now"}
          </Button>
          <p className="text-xs text-muted-foreground mt-2 text-center">You will not be charged until a payment provider is configured and you authorize payment.</p>
        </div>
        <div className="rounded-2xl border bg-card p-6">
          <h3 className="font-semibold mb-3">What stays if you don't subscribe</h3>
          <p className="text-sm text-muted-foreground mb-3">If your trial or subscription expires, we never delete your data:</p>
          <ul className="space-y-2 text-sm">
            {["Gift cards & balances", "Customers & designs", "Transaction history", "API configuration", "Business records"].map((f) => (
              <li key={f} className="flex items-center gap-2"><Check className="w-4 h-4 text-emerald-500" /> {f}</li>
            ))}
          </ul>
          <p className="text-xs text-muted-foreground mt-3">Only business management features are restricted until you renew.</p>
        </div>
      </div>
    </div>
  );
}