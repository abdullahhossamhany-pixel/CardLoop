const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { useAuth } from "@/lib/AuthContext";

import { PageHeader, LoadingState, EmptyState } from "@/components/ui-parts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Users, Plus, Pencil, Trash2, Mail, Phone } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "@/components/ui/use-toast";

export default function Customers() {
  const { user } = useAuth();
  const [items, setItems] = useState(null);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ name: "", email: "", phone: "", notes: "" });

  const load = async () => { try { setItems(await db.entities.Customer.filter({ business_id: user.data.business_id })); } catch { setItems([]); } };
  useEffect(() => { load(); }, [user]);

  const save = async () => {
    if (!form.name) { toast({ title: "Name required", variant: "destructive" }); return; }
    try {
      if (editing) await db.entities.Customer.update(editing.id, form);
      else await db.entities.Customer.create({ ...form, business_id: user.data.business_id });
      setOpen(false); await load(); toast({ title: "Customer saved" });
    } catch (e) { toast({ title: "Failed", description: e.message, variant: "destructive" }); }
  };

  const remove = async (c) => { try { await db.entities.Customer.delete(c.id); await load(); } catch (e) { toast({ title: "Failed", variant: "destructive" }); } };

  if (items === null) return <LoadingState />;

  return (
    <div>
      <PageHeader title="Customers" subtitle="People who receive your gift cards" actions={<Button onClick={() => { setEditing(null); setForm({ name: "", email: "", phone: "", notes: "" }); setOpen(true); }}><Plus className="w-4 h-4 mr-1" /> Add customer</Button>} />
      {items.length === 0 ? (
        <EmptyState icon={Users} title="No customers yet" desc="Add customers to assign gift cards to them." action={<Button onClick={() => { setEditing(null); setForm({ name: "", email: "", phone: "", notes: "" }); setOpen(true); }}><Plus className="w-4 h-4 mr-1" /> Add customer</Button>} />
      ) : (
        <div className="rounded-2xl border bg-card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-muted/50 text-muted-foreground">
              <tr><th className="text-left font-medium px-4 py-3">Name</th><th className="text-left font-medium px-4 py-3">Email</th><th className="text-left font-medium px-4 py-3">Phone</th><th className="px-4 py-3"></th></tr>
            </thead>
            <tbody>
              {items.map((c) => (
                <tr key={c.id} className="border-t hover:bg-muted/30">
                  <td className="px-4 py-3 font-medium">{c.name}</td>
                  <td className="px-4 py-3 text-muted-foreground">{c.email || "—"}</td>
                  <td className="px-4 py-3 text-muted-foreground">{c.phone || "—"}</td>
                  <td className="px-4 py-3 text-right">
                    <Button size="icon" variant="ghost" onClick={() => { setEditing(c); setForm({ name: c.name, email: c.email, phone: c.phone, notes: c.notes }); setOpen(true); }}><Pencil className="w-4 h-4" /></Button>
                    <Button size="icon" variant="ghost" onClick={() => remove(c)}><Trash2 className="w-4 h-4 text-rose-600" /></Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editing ? "Edit customer" : "Add customer"}</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="space-y-2"><Label>Name *</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
            <div className="space-y-2"><Label>Email</Label><Input type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
            <div className="space-y-2"><Label>Phone</Label><Input value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} /></div>
            <div className="space-y-2"><Label>Notes</Label><Textarea value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} rows={2} /></div>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={save}>Save</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}