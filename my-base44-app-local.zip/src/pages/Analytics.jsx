const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { useAuth } from "@/lib/AuthContext";

import { PageHeader, LoadingState, StatCard } from "@/components/ui-parts";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";
import { CreditCard, Receipt, TrendingUp, Wallet } from "lucide-react";
import { formatMoney } from "@/lib/giftcard";

export default function Analytics() {
  const { user } = useAuth();
  const [cards, setCards] = useState(null);
  const [txns, setTxns] = useState([]);

  useEffect(() => {
    (async () => {
      try {
        const bid = user.data.business_id;
        setCards(await db.entities.GiftCard.filter({ business_id: bid }));
        setTxns(await db.entities.Transaction.filter({ business_id: bid }, "-created_date", 100));
      } catch { setCards([]); }
    })();
  }, [user]);

  if (cards === null) return <LoadingState />;

  // last 7 days txn volume
  const days = [...Array(7)].map((_, i) => {
    const d = new Date(); d.setDate(d.getDate() - (6 - i));
    const label = d.toLocaleDateString(undefined, { weekday: "short" });
    const vol = txns.filter((t) => new Date(t.created_date).toDateString() === d.toDateString() && t.type === "redeem").reduce((s, t) => s + t.amount, 0);
    return { day: label, volume: vol };
  });

  const statusData = ["active", "frozen", "redeemed", "expired", "revoked"].map((s) => ({ name: s, value: cards.filter((c) => c.status === s).length })).filter((d) => d.value > 0);
  const COLORS = ["#10b981", "#3b82f6", "#a855f7", "#f59e0b", "#f43f5e"];
  const totalBalance = cards.reduce((s, c) => s + (c.balance || 0), 0);

  return (
    <div>
      <PageHeader title="Analytics" subtitle="Insights into your gift card program" />
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Total cards" value={cards.length} icon={CreditCard} tone="violet" />
        <StatCard label="Active cards" value={cards.filter((c) => c.status === "active").length} icon={TrendingUp} tone="emerald" />
        <StatCard label="Outstanding balance" value={formatMoney(totalBalance)} icon={Wallet} tone="blue" />
        <StatCard label="Transactions" value={txns.length} icon={Receipt} tone="amber" />
      </div>
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="rounded-2xl border bg-card p-5">
          <h3 className="font-semibold mb-4">Redemption volume (last 7 days)</h3>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={days}><XAxis dataKey="day" fontSize={12} /><YAxis fontSize={12} /><Tooltip /><Bar dataKey="volume" fill="#7c3aed" radius={[6, 6, 0, 0]} /></BarChart>
          </ResponsiveContainer>
        </div>
        <div className="rounded-2xl border bg-card p-5">
          <h3 className="font-semibold mb-4">Cards by status</h3>
          {statusData.length === 0 ? <p className="text-sm text-muted-foreground">No data yet</p> : (
            <ResponsiveContainer width="100%" height={260}>
              <PieChart><Pie data={statusData} dataKey="value" nameKey="name" cx="50%" cy="50%" outerRadius={90} label>{statusData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}</Pie><Legend /></PieChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>
    </div>
  );
}