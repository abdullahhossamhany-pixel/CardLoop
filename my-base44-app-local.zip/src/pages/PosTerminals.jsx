const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { useAuth } from "@/lib/AuthContext";

import { PageHeader, LoadingState, EmptyState, Badge } from "@/components/ui-parts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CreditCard, Plus, Trash2, Copy, Ban, Play } from "lucide-react";
import { generateTerminalId, generateUuid, hashPin } from "@/lib/giftcard";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "@/components/ui/use-toast";

export default function PosTerminals() {
  const { user } = useAuth();
  const [items, setItems] = useState(null);
  const [stores, setStores] = useState([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ name: "", store_id: "" });
  const [created, setCreated] = useState(null);

  const load = async () => {
    try {
      setItems(await db.entities.PosTerminal.filter({ business_id: user.data.business_id }));
      setStores(await db.entities.Store.filter({ business_id: user.data.business_id }));
    } catch { setItems([]); }
  };
  useEffect(() => { load(); }, [user]);

  const create = async () => {
    if (!form.name) { toast({ title: "Name required", variant: "destructive" }); return; }
    try {
      const terminalId = generateTerminalId();
      const secret = generateUuid().replace(/-/g, "").slice(0, 24);
      const secretHash = await hashPin(secret);
      const t = await db.entities.PosTerminal.create({
        business_id: user.data.business_id,
        store_id: form.store_id || undefined,
        name: form.name,
        terminal_id: terminalId,
        terminal_secret_hash: secretHash,
        status: "active",
      });
      setCreated({ terminal_id: terminalId, secret });
      setOpen(false); setForm({ name: "", store_id: "" }); await load();
      toast({ title: "POS terminal created" });
    } catch (e) { toast({ title: "Failed", description: e.message, variant: "destructive" }); }
  };

  const setStatus = async (t, status) => { try { await db.entities.PosTerminal.update(t.id, { status }); await load(); } catch {} };
  const remove = async (t) => { try { await db.entities.PosTerminal.delete(t.id); await load(); } catch {} };

  if (items === null) return <LoadingState />;

  return (
    <div>
      <PageHeader title="POS Systems" subtitle="Register and manage POS terminals" actions={<Button onClick={() => { setForm({ name: "", store_id: "" }); setOpen(true); }}><Plus className="w-4 h-4 mr-1" /> Register POS</Button>} />
      {items.length === 0 ? (
        <EmptyState icon={CreditCard} title="No POS terminals" desc="Register a POS terminal to redeem gift cards in-store." action={<Button onClick={() => setOpen(true)}><Plus className="w-4 h-4 mr-1" /> Register POS</Button>} />
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {items.map((t) => (
            <div key={t.id} className="rounded-2xl border bg-card p-5">
              <div className="flex items-start justify-between">
                <div>
                  <h3 className="font-semibold">{t.name}</h3>
                  <p className="text-xs font-mono text-muted-foreground mt-1">{t.terminal_id}</p>
                </div>
                <Badge status={t.status} />
              </div>
              <div className="flex gap-2 mt-4">
                {t.status === "active" && <Button size="sm" variant="outline" onClick={() => setStatus(t, "disabled")}><Ban className="w-3.5 h-3.5 mr-1" /> Disable</Button>}
                {t.status === "disabled" && <Button size="sm" variant="outline" onClick={() => setStatus(t, "active")}><Play className="w-3.5 h-3.5 mr-1" /> Enable</Button>}
                <Button size="sm" variant="outline" onClick={() => setStatus(t, "revoked")}>Revoke</Button>
                <Button size="sm" variant="ghost" onClick={() => remove(t)}><Trash2 className="w-3.5 h-3.5 text-rose-600" /></Button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Register POS terminal</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="space-y-2"><Label>Terminal name *</Label><Input value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Front counter POS" /></div>
            <div className="space-y-2"><Label>Store</Label>
              <select value={form.store_id} onChange={(e) => setForm({ ...form, store_id: e.target.value })} className="w-full h-10 rounded-md border bg-background px-3 text-sm">
                <option value="">— None —</option>
                {stores.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </div>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={create}>Create</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      {created && (
        <Dialog open onOpenChange={() => setCreated(null)}>
          <DialogContent>
            <DialogHeader><DialogTitle>POS credentials (shown once)</DialogTitle></DialogHeader>
            <div className="space-y-3">
              <div className="p-3 rounded-lg bg-muted"><p className="text-xs text-muted-foreground">Terminal ID</p><p className="font-mono font-semibold">{created.terminal_id}</p></div>
              <div className="p-3 rounded-lg bg-violet-50 dark:bg-violet-950/30 border border-violet-200"><p className="text-xs text-muted-foreground">Terminal secret</p><p className="font-mono font-semibold text-sm break-all">{created.secret}</p></div>
              <p className="text-xs text-muted-foreground">Store these securely. The secret is hashed and cannot be recovered.</p>
            </div>
            <DialogFooter><Button onClick={() => setCreated(null)}>Done</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}