const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { useAuth } from "@/lib/AuthContext";

import { PageHeader, LoadingState, EmptyState } from "@/components/ui-parts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Layers, Plus, Pencil, Trash2, Loader2 } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "@/components/ui/use-toast";

export default function Programs() {
  const { user } = useAuth();
  const [items, setItems] = useState(null);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState(null);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({ name: "", description: "", currency: "USD", min_value: 1, max_value: 1000, online_redemption: true, in_store_redemption: true, nfc_available: false, terms: "", expiration_rules: "" });

  const load = async () => {
    try { setItems(await db.entities.GiftCardProgram.filter({ business_id: user.data.business_id })); }
    catch (e) { setItems([]); }
  };
  useEffect(() => { load(); }, [user]);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const openNew = () => { setEditing(null); setForm({ name: "", description: "", currency: "USD", min_value: 1, max_value: 1000, online_redemption: true, in_store_redemption: true, nfc_available: false, terms: "", expiration_rules: "" }); setOpen(true); };
  const openEdit = (p) => { setEditing(p); setForm({ ...p }); setOpen(true); };

  const save = async () => {
    if (!form.name) { toast({ title: "Name required", variant: "destructive" }); return; }
    setSaving(true);
    try {
      if (editing) await db.entities.GiftCardProgram.update(editing.id, form);
      else await db.entities.GiftCardProgram.create({ ...form, business_id: user.data.business_id, is_active: true });
      setOpen(false); await load();
      toast({ title: "Program saved" });
    } catch (e) { toast({ title: "Failed", description: e.message, variant: "destructive" }); }
    finally { setSaving(false); }
  };

  const remove = async (p) => {
    try { await db.entities.GiftCardProgram.delete(p.id); await load(); toast({ title: "Program deleted" }); }
    catch (e) { toast({ title: "Failed", description: e.message, variant: "destructive" }); }
  };

  if (items === null) return <LoadingState />;

  return (
    <div>
      <PageHeader title="Gift Card Programs" subtitle="Create multiple programs with custom rules" actions={<Button onClick={openNew}><Plus className="w-4 h-4 mr-1" /> New program</Button>} />
      {items.length === 0 ? (
        <EmptyState icon={Layers} title="No programs yet" desc="Programs let you group gift cards with shared rules, currency, and designs." action={<Button onClick={openNew}><Plus className="w-4 h-4 mr-1" /> New program</Button>} />
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {items.map((p) => (
            <div key={p.id} className="rounded-2xl border bg-card p-5">
              <div className="flex items-start justify-between">
                <div className="w-10 h-10 rounded-lg bg-violet-100 dark:bg-violet-900/40 flex items-center justify-center"><Layers className="w-5 h-5 text-violet-600" /></div>
                <div className="flex gap-1">
                  <Button size="icon" variant="ghost" onClick={() => openEdit(p)}><Pencil className="w-4 h-4" /></Button>
                  <Button size="icon" variant="ghost" onClick={() => remove(p)}><Trash2 className="w-4 h-4 text-rose-600" /></Button>
                </div>
              </div>
              <h3 className="font-semibold mt-3">{p.name}</h3>
              <p className="text-sm text-muted-foreground mt-1 line-clamp-2">{p.description || "No description"}</p>
              <div className="mt-3 flex flex-wrap gap-2 text-xs">
                <span className="px-2 py-0.5 rounded-full bg-muted">{p.currency}</span>
                <span className="px-2 py-0.5 rounded-full bg-muted">Min {p.min_value}</span>
                <span className="px-2 py-0.5 rounded-full bg-muted">Max {p.max_value}</span>
                {p.online_redemption && <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40">Online</span>}
                {p.in_store_redemption && <span className="px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 dark:bg-blue-900/40">In-store</span>}
                {p.nfc_available && <span className="px-2 py-0.5 rounded-full bg-violet-100 text-violet-700 dark:bg-violet-900/40">NFC</span>}
              </div>
            </div>
          ))}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>{editing ? "Edit program" : "New program"}</DialogTitle></DialogHeader>
          <div className="space-y-3 max-h-[60vh] overflow-y-auto">
            <div className="space-y-2"><Label>Name *</Label><Input value={form.name} onChange={(e) => set("name", e.target.value)} /></div>
            <div className="space-y-2"><Label>Description</Label><Textarea value={form.description} onChange={(e) => set("description", e.target.value)} rows={2} /></div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-2"><Label>Currency</Label>
                <select value={form.currency} onChange={(e) => set("currency", e.target.value)} className="w-full h-10 rounded-md border bg-background px-3 text-sm">
                  {["USD", "EUR", "GBP", "SAR", "AED"].map((c) => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div className="space-y-2"><Label>Min value</Label><Input type="number" value={form.min_value} onChange={(e) => set("min_value", Number(e.target.value))} /></div>
              <div className="space-y-2"><Label>Max value</Label><Input type="number" value={form.max_value} onChange={(e) => set("max_value", Number(e.target.value))} /></div>
            </div>
            <div className="space-y-2"><Label>Expiration rules</Label><Input value={form.expiration_rules} onChange={(e) => set("expiration_rules", e.target.value)} placeholder="e.g. Expires 12 months after issue" /></div>
            <div className="space-y-2"><Label>Terms</Label><Textarea value={form.terms} onChange={(e) => set("terms", e.target.value)} rows={2} /></div>
            <div className="flex flex-wrap gap-4">
              {[
                { k: "online_redemption", l: "Online redemption" },
                { k: "in_store_redemption", l: "In-store redemption" },
                { k: "nfc_available", l: "NFC cards available" },
              ].map((o) => (
                <label key={o.k} className="flex items-center gap-2 text-sm">
                  <input type="checkbox" checked={form[o.k]} onChange={(e) => set(o.k, e.target.checked)} className="rounded" />
                  {o.l}
                </label>
              ))}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={save} disabled={saving}>{saving ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : null}Save</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}