import React from "react";
import { cn } from "@/lib/utils";

export function PageHeader({ title, subtitle, actions }) {
  return (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">{title}</h1>
        {subtitle && <p className="text-muted-foreground text-sm mt-1">{subtitle}</p>}
      </div>
      {actions && <div className="flex gap-2">{actions}</div>}
    </div>
  );
}

export function StatCard({ label, value, icon: Icon, tone = "violet" }) {
  const tones = {
    violet: "bg-violet-100 text-violet-600 dark:bg-violet-900/40 dark:text-violet-300",
    emerald: "bg-emerald-100 text-emerald-600 dark:bg-emerald-900/40 dark:text-emerald-300",
    blue: "bg-blue-100 text-blue-600 dark:bg-blue-900/40 dark:text-blue-300",
    amber: "bg-amber-100 text-amber-600 dark:bg-amber-900/40 dark:text-amber-300",
    rose: "bg-rose-100 text-rose-600 dark:bg-rose-900/40 dark:text-rose-300",
    zinc: "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-300",
  };
  return (
    <div className="rounded-2xl border bg-card p-5">
      <div className="flex items-center justify-between">
        <span className="text-sm text-muted-foreground">{label}</span>
        {Icon && <div className={cn("w-9 h-9 rounded-lg flex items-center justify-center", tones[tone])}><Icon className="w-4 h-4" /></div>}
      </div>
      <p className="text-2xl font-bold mt-3">{value}</p>
    </div>
  );
}

export function Badge({ status }) {
  const styles = {
    active: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300",
    frozen: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300",
    redeemed: "bg-purple-100 text-purple-700 dark:bg-purple-900/40 dark:text-purple-300",
    expired: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
    revoked: "bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300",
    deleted: "bg-zinc-200 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400",
    trial: "bg-violet-100 text-violet-700 dark:bg-violet-900/40 dark:text-violet-300",
    active_sub: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300",
    expired_sub: "bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300",
    not_submitted: "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400",
    pending: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
    verified: "bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300",
    rejected: "bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300",
    needs_more_info: "bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300",
    not_configured: "bg-zinc-100 text-zinc-600 dark:bg-zinc-800 dark:text-zinc-400",
  };
  const labels = {
    active_sub: "Active", not_submitted: "Not submitted", needs_more_info: "Needs info", not_configured: "Not configured",
  };
  return <span className={cn("inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium capitalize", styles[status] || styles.active)}>{labels[status] || status}</span>;
}

export function EmptyState({ icon: Icon, title, desc, action }) {
  return (
    <div className="rounded-2xl border border-dashed bg-card p-12 text-center">
      {Icon && <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center mx-auto mb-4"><Icon className="w-6 h-6 text-muted-foreground" /></div>}
      <h3 className="font-semibold">{title}</h3>
      {desc && <p className="text-sm text-muted-foreground mt-1 max-w-sm mx-auto">{desc}</p>}
      {action && <div className="mt-5">{action}</div>}
    </div>
  );
}

export function LoadingState() {
  return (
    <div className="flex items-center justify-center py-20">
      <div className="w-8 h-8 border-4 border-muted border-t-violet-600 rounded-full animate-spin" />
    </div>
  );
}

export function NotConfiguredBanner({ title, desc }) {
  return (
    <div className="rounded-2xl border border-amber-300 bg-amber-50 dark:bg-amber-950/30 p-5">
      <div className="flex items-start gap-3">
        <div className="w-9 h-9 rounded-lg bg-amber-200 dark:bg-amber-900/50 flex items-center justify-center shrink-0">
          <span className="text-amber-700 dark:text-amber-300 font-bold text-sm">!</span>
        </div>
        <div>
          <p className="font-semibold text-amber-800 dark:text-amber-200">{title || "Not configured"}</p>
          <p className="text-sm text-amber-700 dark:text-amber-300/80 mt-0.5">{desc || "This external integration is not connected yet. The UI and data structure are ready — connect a provider to activate it."}</p>
        </div>
      </div>
    </div>
  );
}