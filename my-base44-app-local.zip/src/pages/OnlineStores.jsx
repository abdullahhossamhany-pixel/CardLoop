const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { useAuth } from "@/lib/AuthContext";

import { PageHeader, LoadingState, EmptyState, Badge } from "@/components/ui-parts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Globe, Plus, Trash2, Code } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "@/components/ui/use-toast";

export default function OnlineStores() {
  const { user } = useAuth();
  const [items, setItems] = useState(null);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ store_name: "", website_url: "", integration_info: "" });

  const load = async () => { try { setItems(await db.entities.OnlineStoreIntegration.filter({ business_id: user.data.business_id })); } catch { setItems([]); } };
  useEffect(() => { load(); }, [user]);

  const save = async () => {
    if (!form.store_name) { toast({ title: "Store name required", variant: "destructive" }); return; }
    try {
      await db.entities.OnlineStoreIntegration.create({ ...form, business_id: user.data.business_id, status: "active" });
      setOpen(false); setForm({ store_name: "", website_url: "", integration_info: "" }); await load(); toast({ title: "Online store connected" });
    } catch (e) { toast({ title: "Failed", description: e.message, variant: "destructive" }); }
  };
  const remove = async (s) => { try { await db.entities.OnlineStoreIntegration.delete(s.id); await load(); } catch {} };

  if (items === null) return <LoadingState />;

  return (
    <div>
      <PageHeader title="Online Stores" subtitle="Connect your website integrations" actions={<Button onClick={() => setOpen(true)}><Plus className="w-4 h-4 mr-1" /> Connect store</Button>} />
      {items.length === 0 ? (
        <EmptyState icon={Globe} title="No online stores" desc="Connect your website to redeem gift cards online via API." action={<Button onClick={() => setOpen(true)}><Plus className="w-4 h-4 mr-1" /> Connect store</Button>} />
      ) : (
        <div className="grid sm:grid-cols-2 gap-4">
          {items.map((s) => (
            <div key={s.id} className="rounded-2xl border bg-card p-5">
              <div className="flex items-start justify-between">
                <div className="w-10 h-10 rounded-lg bg-emerald-100 dark:bg-emerald-900/40 flex items-center justify-center"><Globe className="w-5 h-5 text-emerald-600" /></div>
                <Badge status={s.status} />
              </div>
              <h3 className="font-semibold mt-3">{s.store_name}</h3>
              {s.website_url && <a href={s.website_url} target="_blank" rel="noreferrer" className="text-sm text-violet-600 hover:underline mt-1 block truncate">{s.website_url}</a>}
              {s.integration_info && <p className="text-xs text-muted-foreground mt-2">{s.integration_info}</p>}
              <Button size="sm" variant="ghost" className="mt-3 text-rose-600" onClick={() => remove(s)}><Trash2 className="w-3.5 h-3.5 mr-1" /> Remove</Button>
            </div>
          ))}
        </div>
      )}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Connect online store</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="space-y-2"><Label>Store name *</Label><Input value={form.store_name} onChange={(e) => setForm({ ...form, store_name: e.target.value })} /></div>
            <div className="space-y-2"><Label>Website URL</Label><Input value={form.website_url} onChange={(e) => setForm({ ...form, website_url: e.target.value })} placeholder="https://shop.example.com" /></div>
            <div className="space-y-2"><Label>Integration info</Label><Input value={form.integration_info} onChange={(e) => setForm({ ...form, integration_info: e.target.value })} placeholder="Platform, notes…" /></div>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={save}>Connect</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}