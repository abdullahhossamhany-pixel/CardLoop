const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { useAuth } from "@/lib/AuthContext";

import { PageHeader, LoadingState, EmptyState, Badge, NotConfiguredBanner } from "@/components/ui-parts";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ShoppingCart, Plus, CreditCard } from "lucide-react";
import CardPreview from "@/components/CardPreview";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { toast } from "@/components/ui/use-toast";

const STATUSES = ["designing", "pending", "approved", "production", "programming", "shipped", "delivered", "cancelled"];

export default function PhysicalCards() {
  const { user } = useAuth();
  const [orders, setOrders] = useState(null);
  const [designs, setDesigns] = useState([]);
  const [customers, setCustomers] = useState([]);
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ design_id: "", quantity: 100, customer_id: "", shipping_address: "" });

  const load = async () => {
    try {
      const [o, d, c] = await Promise.all([
        db.entities.PhysicalCardOrder.filter({ business_id: user.data.business_id }, "-created_date"),
        db.entities.GiftCardDesign.filter({ business_id: user.data.business_id }),
        db.entities.Customer.filter({ business_id: user.data.business_id }),
      ]);
      setOrders(o); setDesigns(d); setCustomers(c);
    } catch { setOrders([]); }
  };
  useEffect(() => { load(); }, [user]);

  const order = async () => {
    if (!form.design_id || !form.shipping_address) { toast({ title: "Design and address required", variant: "destructive" }); return; }
    try {
      await db.entities.PhysicalCardOrder.create({
        business_id: user.data.business_id,
        design_id: form.design_id,
        quantity: Number(form.quantity),
        customer_id: form.customer_id || undefined,
        shipping_address: form.shipping_address,
        status: "pending",
      });
      setOpen(false); setForm({ design_id: "", quantity: 100, customer_id: "", shipping_address: "" }); await load();
      toast({ title: "Order submitted", description: "Awaiting manufacturer approval." });
    } catch (e) { toast({ title: "Failed", description: e.message, variant: "destructive" }); }
  };

  if (orders === null) return <LoadingState />;
  const selectedDesign = designs.find((d) => d.id === form.design_id);

  return (
    <div>
      <PageHeader title="Physical NFC Cards" subtitle="Order custom NFC gift cards for your stores" actions={<Button onClick={() => setOpen(true)}><Plus className="w-4 h-4 mr-1" /> Order cards</Button>} />
      <NotConfiguredBanner title="NFC card manufacturer not connected" desc="The ordering workflow, design preview, and order tracking are ready. Connect a physical NFC card manufacturer to send orders into production. Balances stay on the server — NFC memory is never trusted for the balance." />
      <div className="mt-6">
        {orders.length === 0 ? (
          <EmptyState icon={ShoppingCart} title="No orders yet" desc="Order custom NFC gift cards using your saved designs." action={<Button onClick={() => setOpen(true)}><Plus className="w-4 h-4 mr-1" /> Order cards</Button>} />
        ) : (
          <div className="space-y-3">
            {orders.map((o) => {
              const d = designs.find((x) => x.id === o.design_id);
              return (
                <div key={o.id} className="rounded-2xl border bg-card p-4 flex flex-col sm:flex-row gap-4">
                  <div className="w-full sm:w-48"><CardPreview design={d || {}} showInfo={false} /></div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between">
                      <h3 className="font-semibold">Order · {o.quantity} cards</h3>
                      <Badge status={o.status} />
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">Design: {d?.name || "—"}</p>
                    <p className="text-sm text-muted-foreground">Ship to: {o.shipping_address}</p>
                    <p className="text-xs text-muted-foreground mt-1">Ordered {new Date(o.created_date).toLocaleDateString()}</p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Order physical NFC cards</DialogTitle></DialogHeader>
          <div className="space-y-3">
            <div className="space-y-2"><Label>Design *</Label>
              <select value={form.design_id} onChange={(e) => setForm({ ...form, design_id: e.target.value })} className="w-full h-10 rounded-md border bg-background px-3 text-sm">
                <option value="">— Select design —</option>
                {designs.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
              </select>
            </div>
            {selectedDesign && (
              <div className="grid grid-cols-2 gap-2">
                <div><p className="text-xs text-muted-foreground mb-1">Front</p><CardPreview design={selectedDesign} side="front" showInfo={false} /></div>
                <div><p className="text-xs text-muted-foreground mb-1">Back</p><CardPreview design={selectedDesign} side="back" showInfo={false} /></div>
              </div>
            )}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2"><Label>Quantity</Label><Input type="number" value={form.quantity} onChange={(e) => setForm({ ...form, quantity: e.target.value })} /></div>
              <div className="space-y-2"><Label>Assign to customer</Label>
                <select value={form.customer_id} onChange={(e) => setForm({ ...form, customer_id: e.target.value })} className="w-full h-10 rounded-md border bg-background px-3 text-sm">
                  <option value="">— None —</option>
                  {customers.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
            </div>
            <div className="space-y-2"><Label>Shipping address *</Label><Input value={form.shipping_address} onChange={(e) => setForm({ ...form, shipping_address: e.target.value })} /></div>
          </div>
          <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={order}>Submit order</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}