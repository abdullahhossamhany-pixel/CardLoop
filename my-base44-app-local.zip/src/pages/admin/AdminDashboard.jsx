const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "@/lib/AuthContext";

import { PageHeader, StatCard, LoadingState, Badge } from "@/components/ui-parts";
import { Button } from "@/components/ui/button";
import { Users, Building2, CreditCard, Receipt, ShieldCheck, Sparkles, Loader2 } from "lucide-react";
import { formatMoney } from "@/lib/giftcard";
import { seedDemoData } from "@/lib/seed";
import { toast } from "@/components/ui/use-toast";

export default function AdminDashboard() {
  const { user, checkUserAuth } = useAuth();
  const [stats, setStats] = useState(null);
  const [seeding, setSeeding] = useState(false);

  const seed = async () => {
    setSeeding(true);
    try {
      const res = await seedDemoData(user);
      await checkUserAuth();
      toast({ title: "Test data seeded", description: `${res.cards} cards created. All marked as TEST DATA.` });
      window.location.href = "/app";
    } catch (e) { toast({ title: "Seed failed", description: e.message, variant: "destructive" }); }
    finally { setSeeding(false); }
  };

  useEffect(() => {
    (async () => {
      try {
        const [users, businesses, cards, txns] = await Promise.all([
          db.entities.User.list(),
          db.entities.Business.list(),
          db.entities.GiftCard.list(),
          db.entities.Transaction.list(),
        ]);
        setStats({ users, businesses, cards, txns });
      } catch (e) { setStats({ users: [], businesses: [], cards: [], txns: [] }); }
    })();
  }, []);

  if (!stats) return <LoadingState />;

  return (
    <div>
      <PageHeader title="Admin Overview" subtitle="Platform administration" actions={
        <Button onClick={seed} disabled={seeding}>
          {seeding ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <Sparkles className="w-4 h-4 mr-1" />}
          {seeding ? "Seeding…" : "Seed test data"}
        </Button>
      } />
      <div className="rounded-2xl bg-gradient-to-r from-slate-800 to-slate-900 p-5 text-white mb-6 flex items-center gap-3">
        <ShieldCheck className="w-6 h-6" />
        <div>
          <p className="font-semibold">Platform Admin Console</p>
          <p className="text-sm opacity-80">All actions here are recorded in the audit log.</p>
        </div>
      </div>
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Users" value={stats.users.length} icon={Users} tone="violet" />
        <StatCard label="Businesses" value={stats.businesses.length} icon={Building2} tone="blue" />
        <StatCard label="Gift cards" value={stats.cards.length} icon={CreditCard} tone="emerald" />
        <StatCard label="Transactions" value={stats.txns.length} icon={Receipt} tone="amber" />
      </div>
      <div className="grid sm:grid-cols-2 gap-4">
        <Link to="/admin/users" className="rounded-2xl border bg-card p-5 hover:shadow-md transition-shadow">
          <Users className="w-5 h-5 text-violet-600 mb-2" /><h3 className="font-semibold">Manage users</h3><p className="text-sm text-muted-foreground">View and manage all platform users.</p>
        </Link>
        <Link to="/admin/businesses" className="rounded-2xl border bg-card p-5 hover:shadow-md transition-shadow">
          <Building2 className="w-5 h-5 text-blue-600 mb-2" /><h3 className="font-semibold">Manage businesses</h3><p className="text-sm text-muted-foreground">Review businesses and verification status.</p>
        </Link>
        <Link to="/admin/settings" className="rounded-2xl border bg-card p-5 hover:shadow-md transition-shadow">
          <ShieldCheck className="w-5 h-5 text-emerald-600 mb-2" /><h3 className="font-semibold">Platform settings</h3><p className="text-sm text-muted-foreground">Configure NOW Payments and integrations.</p>
        </Link>
        <Link to="/admin/transactions" className="rounded-2xl border bg-card p-5 hover:shadow-md transition-shadow">
          <Receipt className="w-5 h-5 text-amber-600 mb-2" /><h3 className="font-semibold">All transactions</h3><p className="text-sm text-muted-foreground">Platform-wide transaction ledger.</p>
        </Link>
      </div>
    </div>
  );
}