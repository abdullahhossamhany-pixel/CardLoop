import React from "react";
import { cn } from "@/lib/utils";

// Renders a gift card design as a realistic preview.
// design: { front_image_url, front_elements, front_background }
// cardData: { card_number, balance, currency, customer_name, business_name, expiration_date }
export default function CardPreview({ design, cardData = {}, side = "front", className, showInfo = true }) {
  const bg = (side === "front" ? design?.front_background : design?.back_background) || {};
  const elements = (side === "front" ? design?.front_elements : design?.back_elements) || [];
  const uploadedUrl = side === "front" ? design?.front_image_url : design?.back_image_url;

  const bgStyle = {};
  if (bg.type === "solid" && bg.color) bgStyle.background = bg.color;
  else if (bg.type === "gradient" && bg.gradient) bgStyle.background = bg.gradient;
  else if (bg.type === "image" && bg.image) bgStyle.backgroundImage = `url(${bg.image})`;
  else bgStyle.background = "linear-gradient(135deg, #7c3aed, #d946ef)";

  const replacePlaceholders = (text) => {
    if (!text) return "";
    return text
      .replace(/\{\{customer_name\}\}/g, cardData.customer_name || "Recipient")
      .replace(/\{\{gift_card_number\}\}/g, cardData.card_number || "")
      .replace(/\{\{expiry_date\}\}/g, cardData.expiration_date || "")
      .replace(/\{\{business_name\}\}/g, cardData.business_name || "")
      .replace(/\{\{balance\}\}/g, cardData.balance != null ? cardData.balance : "");
  };

  return (
    <div
      className={cn(
        "relative w-full aspect-[1.586/1] rounded-2xl overflow-hidden shadow-xl select-none",
        className
      )}
      style={bgStyle}
    >
      {bg.type === "image" && bg.image && (
        <img src={bg.image} alt="" className="absolute inset-0 w-full h-full object-cover" />
      )}
      {uploadedUrl && (
        <img src={uploadedUrl} alt="" className="absolute inset-0 w-full h-full object-cover" />
      )}

      {elements.map((el) => {
        const style = {
          position: "absolute",
          left: `${el.x}%`,
          top: `${el.y}%`,
          width: `${el.w}%`,
          height: `${el.h}%`,
          transform: `rotate(${el.rotation || 0}deg)`,
          opacity: el.opacity != null ? el.opacity : 1,
          zIndex: el.z || 0,
        };
        if (el.type === "text") {
          return (
            <div
              key={el.id}
              style={{
                ...style,
                color: el.color || "#ffffff",
                fontSize: `${el.fontSize || 16}px`,
                fontWeight: el.bold ? "700" : el.fontWeight || "400",
                fontStyle: el.italic ? "italic" : "normal",
                textAlign: el.align || "left",
                letterSpacing: `${el.letterSpacing || 0}px`,
                fontFamily: el.font || "ui-sans-serif, system-ui, sans-serif",
                display: "flex",
                alignItems: "center",
                justifyContent: el.align === "center" ? "center" : el.align === "right" ? "flex-end" : "flex-start",
                overflow: "hidden",
                wordBreak: "break-word",
              }}
            >
              {replacePlaceholders(el.text)}
            </div>
          );
        }
        if (el.type === "image") {
          return (
            <img
              key={el.id}
              src={el.src}
              alt=""
              style={{ ...style, objectFit: "cover", borderRadius: el.borderRadius || 0 }}
            />
          );
        }
        if (el.type === "shape") {
          return (
            <div
              key={el.id}
              style={{
                ...style,
                background: el.fill || "transparent",
                border: el.border || "none",
                borderRadius: el.shape === "circle" ? "9999px" : el.shape === "rounded" ? "12px" : el.shape === "line" ? "0" : "0",
                height: el.shape === "line" ? `${Math.max(el.h, 1.5)}%` : style.height,
              }}
            />
          );
        }
        return null;
      })}

      {showInfo && elements.length === 0 && !uploadedUrl && (
        <div className="absolute inset-0 flex flex-col justify-between p-5 text-white">
          <div className="flex justify-between items-start opacity-90">
            <span className="font-semibold text-lg">{cardData.business_name || "GiftLoop"}</span>
          </div>
          <div>
            <p className="text-2xl font-bold">{cardData.balance != null ? cardData.balance : ""}</p>
            <p className="font-mono text-sm tracking-widest opacity-90">{cardData.card_number || ""}</p>
          </div>
        </div>
      )}
    </div>
  );
}